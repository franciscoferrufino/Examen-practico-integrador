package edu.uam.tecnouam.config;

import edu.uam.tecnouam.model.*;
import edu.uam.tecnouam.repository.EquipoRepository;
import edu.uam.tecnouam.repository.PrestamoRepository;
import edu.uam.tecnouam.repository.UsuarioRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;

/**
 * Inicializador reproducible de cuentas de prueba (ADMIN y USER con BCrypt)
 * y datos base de equipos/préstamos en caso de iniciar con una base de datos vacía.
 */
@Component
public class DataInitializer implements CommandLineRunner {

    private final UsuarioRepository usuarioRepository;
    private final EquipoRepository equipoRepository;
    private final PrestamoRepository prestamoRepository;
    private final PasswordEncoder passwordEncoder;

    @Value("${app.seed.admin-username:admin}")
    private String adminUsername;

    @Value("${app.seed.admin-password:admin123}")
    private String adminPassword;

    @Value("${app.seed.user-username:user}")
    private String userUsername;

    @Value("${app.seed.user-password:user123}")
    private String userPassword;

    public DataInitializer(
            UsuarioRepository usuarioRepository,
            EquipoRepository equipoRepository,
            PrestamoRepository prestamoRepository,
            PasswordEncoder passwordEncoder
    ) {
        this.usuarioRepository = usuarioRepository;
        this.equipoRepository = equipoRepository;
        this.prestamoRepository = prestamoRepository;
        this.passwordEncoder = passwordEncoder;
    }

    @Override
    @Transactional
    public void run(String... args) {
        sincronizarUsuario(adminUsername, adminPassword, "Administrador TecnoUAM", RolUsuario.ADMIN);
        sincronizarUsuario(userUsername, userPassword, "Instructor Consultor TecnoUAM", RolUsuario.USER);
        sincronizarUsuario("instructor", userPassword, "Prof. Carlos Mendoza (Instructor UAM)", RolUsuario.USER);

        if (equipoRepository.count() == 0) {
            Equipo lap1 = equipoRepository.save(new Equipo(
                    "UAM-LAP-001",
                    "Laptop Dell Latitude 5540 Core i7",
                    TipoEquipo.COMPUTADORA_PORTATIL.getEtiqueta(),
                    EstadoEquipo.DISPONIBLE
            ));
            Equipo lap2 = equipoRepository.save(new Equipo(
                    "UAM-LAP-002",
                    "MacBook Air M2 13 Pulgadas",
                    TipoEquipo.COMPUTADORA_PORTATIL.getEtiqueta(),
                    EstadoEquipo.PRESTADO
            ));
            Equipo pro1 = equipoRepository.save(new Equipo(
                    "UAM-PRO-001",
                    "Proyector Epson PowerLite E20 3400L",
                    TipoEquipo.PROYECTOR.getEtiqueta(),
                    EstadoEquipo.DISPONIBLE
            ));
            Equipo pro2 = equipoRepository.save(new Equipo(
                    "UAM-PRO-002",
                    "Proyector BenQ MH560 Full HD",
                    TipoEquipo.PROYECTOR.getEtiqueta(),
                    EstadoEquipo.DISPONIBLE
            ));
            Equipo tab1 = equipoRepository.save(new Equipo(
                    "UAM-TAB-001",
                    "iPad Air 5ta Generación 64GB",
                    TipoEquipo.TABLETA.getEtiqueta(),
                    EstadoEquipo.DISPONIBLE
            ));
            Equipo tab2 = equipoRepository.save(new Equipo(
                    "UAM-TAB-002",
                    "Samsung Galaxy Tab S9 FE",
                    TipoEquipo.TABLETA.getEtiqueta(),
                    EstadoEquipo.PRESTADO
            ));

            Prestamo devuelto = new Prestamo(
                    pro1,
                    "MSc. Roberto Blandón (Aula B-204)",
                    LocalDate.of(2026, 10, 20),
                    LocalDate.of(2026, 10, 22),
                    EstadoPrestamo.DEVUELTO
            );
            devuelto.setFechaDevolucionReal(LocalDate.of(2026, 10, 22));
            prestamoRepository.save(devuelto);

            prestamoRepository.save(new Prestamo(
                    lap2,
                    "Ing. María Fernanda Solís (Lab Redes)",
                    LocalDate.of(2026, 10, 27),
                    LocalDate.of(2026, 10, 30),
                    EstadoPrestamo.ACTIVO
            ));

            prestamoRepository.save(new Prestamo(
                    tab2,
                    "Dr. Alejandro Vega (Auditorio Central)",
                    LocalDate.of(2026, 10, 28),
                    LocalDate.of(2026, 10, 31),
                    EstadoPrestamo.ACTIVO
            ));
        }
    }

    private void sincronizarUsuario(String username, String rawPassword, String nombreCompleto, RolUsuario rol) {
        Usuario usuario = usuarioRepository.findByUsernameIgnoreCase(username)
                .orElseGet(() -> new Usuario(username, passwordEncoder.encode(rawPassword), nombreCompleto, rol));
        usuario.setPassword(passwordEncoder.encode(rawPassword));
        usuario.setNombreCompleto(nombreCompleto);
        usuario.setRol(rol);
        usuarioRepository.save(usuario);
    }
}
