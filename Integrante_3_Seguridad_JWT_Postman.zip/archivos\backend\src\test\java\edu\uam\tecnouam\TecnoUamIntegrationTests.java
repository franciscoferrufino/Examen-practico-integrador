package edu.uam.tecnouam;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import edu.uam.tecnouam.dto.EquipoRequestDTO;
import edu.uam.tecnouam.dto.LoginRequestDTO;
import edu.uam.tecnouam.dto.PrestamoRequestDTO;
import org.junit.jupiter.api.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.*;

import static org.assertj.core.api.Assertions.assertThat;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Suite de pruebas automatizadas de integración para TecnoUAM.
 * Verifica los 13 casos obligatorios de seguridad (JWT/roles 401/403), CRUD,
 * reglas de negocio (400/404/409), atomicidad transaccional y concurrencia.
 * Responsabilidad técnica: Integrante 5 (Pruebas, integración y evidencias).
 */
@SpringBootTest
@AutoConfigureMockMvc
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class TecnoUamIntegrationTests {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    private String obtenerToken(String username, String password) throws Exception {
        LoginRequestDTO login = new LoginRequestDTO(username, password);
        MvcResult result = mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(login)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.token").isNotEmpty())
                .andReturn();

        JsonNode json = objectMapper.readTree(result.getResponse().getContentAsString());
        return json.get("token").asText();
    }

    @Test
    @Order(1)
    @DisplayName("1. Login ADMIN y USER exitoso (200 OK) y Login incorrecto (401 Unauthorized)")
    void testLoginAdminUserYCredencialesInvalidas() throws Exception {
        String adminToken = obtenerToken("admin", "admin123");
        String userToken = obtenerToken("user", "user123");

        assertThat(adminToken).isNotBlank();
        assertThat(userToken).isNotBlank();

        // Login con contraseña incorrecta -> 401
        LoginRequestDTO badLogin = new LoginRequestDTO("admin", "claveIncorrecta");
        mockMvc.perform(post("/api/auth/login")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(badLogin)))
                .andExpect(status().isUnauthorized());
    }

    @Test
    @Order(2)
    @DisplayName("2. Seguridad: Consulta sin token (401), Consulta con USER (200) y Creación con USER (403)")
    void testReglasDeSeguridadYPermisos() throws Exception {
        // 8. Consulta sin token -> 401 Unauthorized
        mockMvc.perform(get("/api/equipos"))
                .andExpect(status().isUnauthorized());

        mockMvc.perform(get("/api/prestamos"))
                .andExpect(status().isUnauthorized());

        String userToken = obtenerToken("user", "user123");

        // 9. Consulta con USER -> 200 OK
        mockMvc.perform(get("/api/equipos")
                        .header("Authorization", "Bearer " + userToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());

        mockMvc.perform(get("/api/prestamos")
                        .header("Authorization", "Bearer " + userToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$").isArray());

        // 10. Creación con USER -> 403 Forbidden
        EquipoRequestDTO IntentoUser = new EquipoRequestDTO("UAM-PRO-999", "Proyector No Autorizado", "Proyector", "DISPONIBLE");
        mockMvc.perform(post("/api/equipos")
                        .header("Authorization", "Bearer " + userToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(IntentoUser)))
                .andExpect(status().isForbidden());
    }

    @Test
    @Order(3)
    @DisplayName("3. Flujo completo ADMIN: Alta (201), Consulta, Edición (200), Préstamo (201), Conflicto 2do Préstamo (409), Bloqueo eliminación (409), Devolución (200) y Eliminación con historial devuelto (204)")
    void testFlujoCompletoReglasDeNegocio() throws Exception {
        String adminToken = obtenerToken("admin", "admin123");

        // Alta de equipo con ADMIN -> 201 Created
        EquipoRequestDTO nuevoEquipo = new EquipoRequestDTO(
                "UAM-LAP-777",
                "Laptop Lenovo ThinkPad T14 Gen 4",
                "Computadora portátil",
                "DISPONIBLE"
        );

        MvcResult createResult = mockMvc.perform(post("/api/equipos")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nuevoEquipo)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.codigoPatrimonial").value("UAM-LAP-777"))
                .andExpect(jsonPath("$.estado").value("DISPONIBLE"))
                .andReturn();

        Long equipoId = objectMapper.readTree(createResult.getResponse().getContentAsString()).get("id").asLong();

        // Código patrimonial duplicado -> 409 Conflict
        mockMvc.perform(post("/api/equipos")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(nuevoEquipo)))
                .andExpect(status().isConflict());

        // Consulta individual -> 200 OK
        mockMvc.perform(get("/api/equipos/" + equipoId)
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Laptop Lenovo ThinkPad T14 Gen 4"));

        // Actualización de equipo -> 200 OK
        EquipoRequestDTO editarEquipo = new EquipoRequestDTO(
                "UAM-LAP-777",
                "Laptop Lenovo ThinkPad T14 Gen 4 (16GB RAM)",
                "Computadora portátil",
                "DISPONIBLE"
        );
        mockMvc.perform(put("/api/equipos/" + equipoId)
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(editarEquipo)))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.nombre").value("Laptop Lenovo ThinkPad T14 Gen 4 (16GB RAM)"));

        // Impedir cambiar estado manualmente a PRESTADO sin préstamo activo -> 409 Conflict
        EquipoRequestDTO edicionContradictoriaSinPrestamo = new EquipoRequestDTO(
                "UAM-LAP-777",
                "Laptop Lenovo ThinkPad T14 Gen 4 (16GB RAM)",
                "Computadora portátil",
                "PRESTADO"
        );
        mockMvc.perform(put("/api/equipos/" + equipoId)
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(edicionContradictoriaSinPrestamo)))
                .andExpect(status().isConflict());

        // Registro de préstamo -> 201 Created y cambio de equipo a PRESTADO
        PrestamoRequestDTO prestamoReq = new PrestamoRequestDTO(
                equipoId,
                "Ing. Sofía Chamorro",
                LocalDate.of(2026, 10, 28),
                LocalDate.of(2026, 10, 30)
        );

        MvcResult prestamoResult = mockMvc.perform(post("/api/prestamos")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(prestamoReq)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.estado").value("ACTIVO"))
                .andExpect(jsonPath("$.equipo.estado").value("PRESTADO"))
                .andReturn();

        Long prestamoId = objectMapper.readTree(prestamoResult.getResponse().getContentAsString()).get("id").asLong();

        // Verificar que el equipo quedó PRESTADO en GET /api/equipos/{id}
        mockMvc.perform(get("/api/equipos/" + equipoId)
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("PRESTADO"));

        // Rechazo de segundo préstamo activo sobre el mismo equipo -> 409 Conflict
        PrestamoRequestDTO segundoPrestamo = new PrestamoRequestDTO(
                equipoId,
                "Prof. Luis Morales",
                LocalDate.of(2026, 10, 28),
                LocalDate.of(2026, 10, 29)
        );
        mockMvc.perform(post("/api/prestamos")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(segundoPrestamo)))
                .andExpect(status().isConflict());

        // Impedir edición manual a DISPONIBLE mientras tiene préstamo activo -> 409 Conflict
        EquipoRequestDTO edicionContradictoriaConPrestamo = new EquipoRequestDTO(
                "UAM-LAP-777",
                "Laptop Lenovo ThinkPad T14 Gen 4 (16GB RAM)",
                "Computadora portátil",
                "DISPONIBLE"
        );
        mockMvc.perform(put("/api/equipos/" + equipoId)
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(edicionContradictoriaConPrestamo)))
                .andExpect(status().isConflict());

        // Eliminación bloqueada por préstamo activo -> 409 Conflict
        mockMvc.perform(delete("/api/equipos/" + equipoId)
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isConflict());

        // Devolución del préstamo -> 200 OK y equipo vuelve a DISPONIBLE
        mockMvc.perform(put("/api/prestamos/" + prestamoId + "/devolver")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.estado").value("DEVUELTO"))
                .andExpect(jsonPath("$.equipo.estado").value("DISPONIBLE"));

        // Intentar devolver nuevamente un préstamo ya DEVUELTO -> 409 Conflict
        mockMvc.perform(put("/api/prestamos/" + prestamoId + "/devolver")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isConflict());

        // Eliminación permitida del equipo con préstamo ya DEVUELTO -> 204 No Content (sin error de FK)
        mockMvc.perform(delete("/api/equipos/" + equipoId)
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isNoContent());

        // Verificar que ya no existe -> 404 Not Found
        mockMvc.perform(get("/api/equipos/" + equipoId)
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isNotFound());
    }

    @Test
    @Order(4)
    @DisplayName("4. Validaciones 400 (fechas inválidas, tipo inválido, campos vacíos) y 404 (recursos inexistentes)")
    void testValidacionesFechasCamposYRecursosInexistentes() throws Exception {
        String adminToken = obtenerToken("admin", "admin123");

        // Tipo de equipo inválido -> 400 Bad Request
        EquipoRequestDTO tipoInvalido = new EquipoRequestDTO("UAM-IMP-001", "Impresora Laser", "Impresora", "DISPONIBLE");
        mockMvc.perform(post("/api/equipos")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(tipoInvalido)))
                .andExpect(status().isBadRequest());

        // Fecha prevista de devolución anterior a fecha de préstamo -> 400 Bad Request
        PrestamoRequestDTO fechaInvalida = new PrestamoRequestDTO(
                1L,
                "Instructor Prueba Fechas",
                LocalDate.of(2026, 10, 28),
                LocalDate.of(2026, 10, 25)
        );
        mockMvc.perform(post("/api/prestamos")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(fechaInvalida)))
                .andExpect(status().isBadRequest());

        // Recurso inexistente en GET, PUT, DELETE y préstamos -> 404 Not Found
        mockMvc.perform(get("/api/equipos/99999")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isNotFound());

        mockMvc.perform(delete("/api/equipos/99999")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isNotFound());

        mockMvc.perform(put("/api/prestamos/99999/devolver")
                        .header("Authorization", "Bearer " + adminToken))
                .andExpect(status().isNotFound());
    }

    @Test
    @Order(5)
    @DisplayName("5. Concurrencia: Solicitudes simultáneas de préstamo sobre el mismo equipo solo permiten 1 activo")
    void testSolicitudesSimultaneasDePrestamo() throws Exception {
        String adminToken = obtenerToken("admin", "admin123");

        EquipoRequestDTO equipoConcurrencia = new EquipoRequestDTO(
                "UAM-TAB-888",
                "iPad Pro Concurrencia Test",
                "Tableta",
                "DISPONIBLE"
        );
        MvcResult res = mockMvc.perform(post("/api/equipos")
                        .header("Authorization", "Bearer " + adminToken)
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(equipoConcurrencia)))
                .andExpect(status().isCreated())
                .andReturn();

        Long equipoId = objectMapper.readTree(res.getResponse().getContentAsString()).get("id").asLong();

        int numHilos = 2;
        ExecutorService executor = Executors.newFixedThreadPool(numHilos);
        CountDownLatch readyLatch = new CountDownLatch(numHilos);
        CountDownLatch startLatch = new CountDownLatch(1);
        List<Future<Integer>> resultados = new ArrayList<>();

        for (int i = 1; i <= numHilos; i++) {
            final int indice = i;
            resultados.add(executor.submit(() -> {
                PrestamoRequestDTO req = new PrestamoRequestDTO(
                        equipoId,
                        "Solicitante Concurrente " + indice,
                        LocalDate.of(2026, 10, 28),
                        LocalDate.of(2026, 10, 30)
                );
                String payload = objectMapper.writeValueAsString(req);
                readyLatch.countDown();
                startLatch.await(5, TimeUnit.SECONDS);

                MvcResult mvcRes = mockMvc.perform(post("/api/prestamos")
                                .header("Authorization", "Bearer " + adminToken)
                                .contentType(MediaType.APPLICATION_JSON)
                                .content(payload))
                        .andReturn();
                return mvcRes.getResponse().getStatus();
            }));
        }

        readyLatch.await(5, TimeUnit.SECONDS);
        startLatch.countDown();

        List<Integer> codigosHttp = new ArrayList<>();
        for (Future<Integer> futuro : resultados) {
            codigosHttp.add(futuro.get(10, TimeUnit.SECONDS));
        }
        executor.shutdown();

        // Exactamente una solicitud debe retornar 201 Created y la otra debe rechazarse con 409 Conflict
        assertThat(codigosHttp).containsExactlyInAnyOrder(201, 409);
    }
}
