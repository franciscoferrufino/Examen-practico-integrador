@echo off
cd /d "%~dp0"
echo Clonando repositorio de TecnoUAM...
if exist repo_uam rmdir /s /q repo_uam
git clone https://github.com/franciscoferrufino/Examen-practico-integrador.git repo_uam
xcopy /E /I /Y "archivos\*" "repo_uam\"
cd repo_uam
git add .
git commit -m "feat(security-jwt): autenticacion JWT, BCrypt, roles ADMIN/USER (401/403), tests JUnit y coleccion Postman"
git push origin main
echo.
echo ==========================================================
echo   LISTO! TU COMMIT DE INTEGRANTE 3 SE SUBIO A GITHUB
echo ==========================================================
pause
