package edu.uam.tecnouam.controller;

import edu.uam.tecnouam.dto.LoginRequestDTO;
import edu.uam.tecnouam.dto.LoginResponseDTO;
import edu.uam.tecnouam.model.Usuario;
import edu.uam.tecnouam.repository.UsuarioRepository;
import edu.uam.tecnouam.security.JwtService;
import jakarta.validation.Valid;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.web.bind.annotation.*;

/**
 * Controlador de autenticación para inicio de sesión y emisión de JWT firmado.
 * Endpoint obligatorio: POST /api/auth/login
 * Responsabilidad técnica: Integrante 3 (Spring Security, JWT y roles).
 */
@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final AuthenticationManager authenticationManager;
    private final UsuarioRepository usuarioRepository;
    private final JwtService jwtService;

    public AuthController(
            AuthenticationManager authenticationManager,
            UsuarioRepository usuarioRepository,
            JwtService jwtService
    ) {
        this.authenticationManager = authenticationManager;
        this.usuarioRepository = usuarioRepository;
        this.jwtService = jwtService;
    }

    @PostMapping("/login")
    public ResponseEntity<LoginResponseDTO> login(@Valid @RequestBody LoginRequestDTO request) {
        Authentication authentication = authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(request.getUsername().trim(), request.getPassword())
        );

        UserDetails userDetails = (UserDetails) authentication.getPrincipal();
        Usuario usuario = usuarioRepository.findByUsernameIgnoreCase(userDetails.getUsername())
                .orElseThrow(() -> new BadCredentialsException("Credenciales incorrectas."));

        String token = jwtService.generateToken(
                userDetails,
                usuario.getRol().name(),
                usuario.getNombreCompleto()
        );

        LoginResponseDTO response = new LoginResponseDTO(
                token,
                usuario.getUsername(),
                usuario.getNombreCompleto(),
                usuario.getRol().name(),
                jwtService.getExpirationMs()
        );

        return ResponseEntity.ok(response);
    }
}
