import React, { useState, useEffect, useCallback } from 'react';
import axiosClient, {
  obtenerSesionGuardada,
  guardarSesion,
  limpiarSesion,
  registrarManejadorSesionVencida
} from './api/axiosClient';
import LoginForm from './components/LoginForm';
import EquiposTable from './components/EquiposTable';
import PrestamosPanel from './components/PrestamosPanel';

/**
 * Componente raíz funcional que gestiona la sesión JWT y consulta la API protegida
 * mediante Axios, useState y useEffect.
 * Responsabilidad técnica: Integrante 4 (React, Axios y visualización).
 */
export default function App() {
  const [sesion, setSesion] = useState(() => {
    const inicial = obtenerSesionGuardada();
    return inicial && !inicial.expirada ? inicial : null;
  });
  const [mensajeSesionVencida, setMensajeSesionVencida] = useState(() => {
    const inicial = obtenerSesionGuardada();
    return inicial?.expirada
      ? 'Su sesión anterior expiró. Por favor inicie sesión nuevamente.'
      : '';
  });

  const [equipos, setEquipos] = useState([]);
  const [prestamos, setPrestamos] = useState([]);
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');
  const [notificacion, setNotificacion] = useState({ tipo: '', texto: '' });
  const [ultimaActualizacion, setUltimaActualizacion] = useState('');
  const [equipoPreseleccionado, setEquipoPreseleccionado] = useState(null);

  const mostrarNotificacion = (tipo, texto) => {
    setNotificacion({ tipo, texto });
    setTimeout(() => {
      setNotificacion((actual) => (actual.texto === texto ? { tipo: '', texto: '' } : actual));
    }, 5000);
  };

  // Registrar interceptor para manejo automático de sesión vencida (HTTP 401)
  useEffect(() => {
    registrarManejadorSesionVencida((mensaje) => {
      setSesion(null);
      setEquipos([]);
      setPrestamos([]);
      setMensajeSesionVencida(mensaje);
    });
  }, []);

  // Consulta protegida a GET /api/equipos y GET /api/prestamos usando Axios + JWT
  const cargarDatosDesdeApi = useCallback(async () => {
    if (!sesion?.token) return;
    setCargando(true);
    setError('');
    try {
      const [resEquipos, resPrestamos] = await Promise.all([
        axiosClient.get('/equipos'),
        axiosClient.get('/prestamos')
      ]);
      setEquipos(resEquipos.data || []);
      setPrestamos(resPrestamos.data || []);
      setUltimaActualizacion(new Date().toLocaleTimeString('es-NI'));
    } catch (err) {
      if (err.response?.status !== 401) {
        const msg =
          err.response?.data?.message ||
          'No se pudo obtener la información desde la API REST. Verifique que el servidor Spring Boot esté activo.';
        setError(msg);
      }
    } finally {
      setCargando(false);
    }
  }, [sesion?.token]);

  // Ejecutar consulta automáticamente al iniciar sesión o recargar la aplicación
  useEffect(() => {
    if (sesion?.token) {
      cargarDatosDesdeApi();
    }
  }, [sesion?.token, cargarDatosDesdeApi]);

  const manejarLoginExitoso = (datosLogin) => {
    const nuevaSesion = guardarSesion(datosLogin);
    setMensajeSesionVencida('');
    setSesion(nuevaSesion);
  };

  const manejarCerrarSesion = () => {
    limpiarSesion();
    setSesion(null);
    setEquipos([]);
    setPrestamos([]);
    setError('');
  };

  const manejarCrearEquipo = async (payload) => {
    await axiosClient.post('/equipos', payload);
    mostrarNotificacion('success', `Equipo '${payload.codigoPatrimonial}' registrado correctamente.`);
    await cargarDatosDesdeApi();
  };

  const manejarEditarEquipo = async (id, payload) => {
    await axiosClient.put(`/equipos/${id}`, payload);
    mostrarNotificacion('success', `Equipo #${id} actualizado correctamente.`);
    await cargarDatosDesdeApi();
  };

  const manejarEliminarEquipo = async (equipo) => {
    try {
      await axiosClient.delete(`/equipos/${equipo.id}`);
      mostrarNotificacion('success', `Equipo '${equipo.codigoPatrimonial}' eliminado correctamente.`);
      await cargarDatosDesdeApi();
    } catch (err) {
      const msg =
        err.response?.data?.message ||
        'No se pudo eliminar el equipo (verifique que no tenga préstamos activos).';
      mostrarNotificacion('error', msg);
    }
  };

  const manejarRegistrarPrestamo = async (payload) => {
    await axiosClient.post('/prestamos', payload);
    mostrarNotificacion('success', 'Préstamo registrado y estado del equipo actualizado a PRESTADO.');
    await cargarDatosDesdeApi();
  };

  const manejarDevolverPrestamo = async (prestamo) => {
    try {
      await axiosClient.put(`/prestamos/${prestamo.id}/devolver`);
      mostrarNotificacion(
        'success',
        `Devolución registrada. El equipo '${prestamo.equipo?.codigoPatrimonial}' ahora está DISPONIBLE.`
      );
      await cargarDatosDesdeApi();
    } catch (err) {
      const msg = err.response?.data?.message || 'No se pudo registrar la devolución.';
      mostrarNotificacion('error', msg);
    }
  };

  if (!sesion) {
    return (
      <LoginForm
        onLoginSuccess={manejarLoginExitoso}
        mensajeSesionVencida={mensajeSesionVencida}
      />
    );
  }

  const esAdmin = sesion.rol === 'ADMIN';
  const totalEquipos = equipos.length;
  const disponibles = equipos.filter((e) => e.estado === 'DISPONIBLE');
  const prestados = equipos.filter((e) => e.estado === 'PRESTADO');

  return (
    <div className="app-layout">
      <header className="top-navbar">
        <div className="navbar-brand">
          <span className="logo-pill">TecnoUAM</span>
          <div>
            <h1>Sistema de Préstamo de Equipos Tecnológicos</h1>
            <p>Universidad Americana (UAM) • Ingeniería de Sistemas</p>
          </div>
        </div>

        <div className="navbar-user">
          <div className="user-info">
            <span className="user-name">{sesion.nombreCompleto || sesion.username}</span>
            <span className={`role-badge ${esAdmin ? 'role-admin' : 'role-user'}`}>
              Rol: {sesion.rol}
            </span>
          </div>
          <button type="button" className="btn btn-outline-light" onClick={manejarCerrarSesion}>
            Cerrar sesión
          </button>
        </div>
      </header>

      <main className="main-container">
        {/* Resumen de indicadores en tiempo real */}
        <div className="stats-grid">
          <div className="stat-card">
            <span className="stat-label">Total de Equipos</span>
            <strong className="stat-value">{totalEquipos}</strong>
          </div>
          <div className="stat-card stat-available">
            <span className="stat-label">Equipos Disponibles</span>
            <strong className="stat-value">{disponibles.length}</strong>
          </div>
          <div className="stat-card stat-loaned">
            <span className="stat-label">Equipos Prestados</span>
            <strong className="stat-value">{prestados.length}</strong>
          </div>
          <div className="stat-card">
            <span className="stat-label">Permisos de la Sesión</span>
            <strong className="stat-role-text">
              {esAdmin ? 'Lectura y Escritura (ADMIN)' : 'Solo Consulta (USER)'}
            </strong>
          </div>
        </div>

        {notificacion.texto && (
          <div
            className={`alert ${
              notificacion.tipo === 'error' ? 'alert-danger' : 'alert-success'
            }`}
            role="status"
          >
            {notificacion.texto}
          </div>
        )}

        {/* Tabla principal de equipos requerida en Reto 3 */}
        <EquiposTable
          equipos={equipos}
          cargando={cargando}
          error={error}
          esAdmin={esAdmin}
          ultimaActualizacion={ultimaActualizacion}
          onActualizarLista={cargarDatosDesdeApi}
          onCrearEquipo={manejarCrearEquipo}
          onEditarEquipo={manejarEditarEquipo}
          onEliminarEquipo={manejarEliminarEquipo}
          onPrestarRapido={(eq) => {
            setEquipoPreseleccionado(eq);
            window.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' });
          }}
        />

        {/* Panel de préstamos y devoluciones */}
        <PrestamosPanel
          prestamos={prestamos}
          equiposDisponibles={disponibles}
          equipoPreseleccionado={equipoPreseleccionado}
          esAdmin={esAdmin}
          cargando={cargando}
          onRegistrarPrestamo={manejarRegistrarPrestamo}
          onDevolverPrestamo={manejarDevolverPrestamo}
          onLimpiarPreseleccion={() => setEquipoPreseleccionado(null)}
        />
      </main>
    </div>
  );
}
