@echo off
title TecnoUAM - Frontend React (Puerto 5173)
echo ============================================================================
echo   TECNO-UAM: INICIANDO FRONTEND REACT + VITE (http://localhost:5173)
echo ============================================================================
cd /d "%~dp0frontend"
call npm run dev
pause

