# Guía de Demostración y Orden de Pruebas (Postman + React)

**Caso:** Sistema de Préstamo de Equipos Tecnológicos — TecnoUAM  
Esta guía detalla el orden exacto de ejecución de las pruebas durante la evaluación y las capturas de pantalla que el equipo debe tomar como evidencia para el **Reto 4**.

---

## Preparación antes de iniciar las capturas

1. Verificar que la base de datos **`TecnoUAM`** esté creada en SQL Server (`database/init-tecnouam.sql`).
2. Iniciar el backend Spring Boot en el puerto `8080`.
3. Iniciar el frontend React en `http://localhost:5173`.
4. En **Postman**, importar:
   - `postman/TecnoUAM_Coleccion_Postman.json`
   - `postman/TecnoUAM_Entorno_Postman.json`
5. Seleccionar el entorno **`TecnoUAM - Entorno Local (Sin Secretos)`** y completar los valores locales:
   - `adminPassword` = `admin123`
   - `userPassword` = `user123`

---

## Orden de Ejecución y Capturas Obligatorias

### Bloque A: Seguridad, Autenticación JWT y Permisos por Rol (Reto 2)

| # | Solicitud en Postman / Acción | Resultado Esperado | Captura a tomar |
| :- | :--- | :--- | :--- |
| **1** | `1.1 Login ADMIN` (`POST /api/auth/login`) | **`200 OK`** con `token`, `rol: "ADMIN"` (guarda automáticamente `{{adminToken}}`). | **Captura 01:** Login exitoso con cuenta `ADMIN` y pestaña *Test Results* en verde. |
| **2** | `1.2 Login USER` (`POST /api/auth/login`) | **`200 OK`** con `token`, `rol: "USER"` (guarda automáticamente `{{userToken}}`). | **Captura 02:** Login exitoso con cuenta `USER`. |
| **3** | `12. Login incorrecto` (`POST /api/auth/login`) | **`401 Unauthorized`** con mensaje `"Credenciales incorrectas o autenticación inválida."` | **Captura 03:** Rechazo 401 ante contraseña inválida. |
| **4** | `8. Consulta de equipos sin token` (`GET /api/equipos`) | **`401 Unauthorized`** con mensaje `"No autenticado: falta el token JWT..."` | **Captura 04:** Respuesta 401 al consultar `/api/equipos` sin encabezado `Authorization`. |
| **5** | `9. Consulta de equipos con token USER` (`GET /api/equipos`) | **`200 OK`** con arreglo JSON de equipos desde SQL Server. | **Captura 05:** Consulta 200 OK autorizada para rol `USER`. |
| **6** | `10. Creación de equipo con token USER` (`POST /api/equipos`) | **`403 Forbidden`** indicando que se requiere rol `ADMIN`. | **Captura 06:** Respuesta 403 Forbidden al intentar crear un equipo con token `USER`. |

---

### Bloque B: CRUD de Equipos, Préstamos, Reglas de Negocio y Sincronización con React (Retos 1, 3 y 4)

| # | Solicitud en Postman / Acción | Resultado Esperado | Captura a tomar |
| :- | :--- | :--- | :--- |
| **7** | Abrir React (`http://localhost:5173`) e iniciar sesión con `admin` / `admin123` | Muestra la tabla inicial de 6 equipos almacenados en SQL Server. | **Captura 07:** Vista inicial de la tabla de equipos en React autenticada con JWT. |
| **8** | `2.1 y 11. Alta válida de equipo con ADMIN` (`POST /api/equipos`) con código `UAM-LAP-500` | **`201 Created`** con `estado: "DISPONIBLE"` (guarda `{{equipoId}}`). | **Captura 08:** Creación 201 de `UAM-LAP-500` en Postman. |
| **9** | En React, hacer clic en el botón **`↻ Actualizar lista`** (o recargar la página) | El equipo `UAM-LAP-500` aparece inmediatamente en la tabla con estado `DISPONIBLE`. | **Captura 09:** Evidencia en React mostrando el nuevo equipo `UAM-LAP-500` creado desde Postman. |
| **10** | `2.2 Consulta individual` (`GET /api/equipos/{{equipoId}}`) y `2.3 Actualización` (`PUT /api/equipos/{{equipoId}}`) | **`200 OK`** reflejando el nombre actualizado `(Actualizada 32GB)`. | **Captura 10:** Actualización 200 OK del equipo en Postman. |
| **11** | `3. Registro de préstamo` (`POST /api/prestamos`) sobre `{{equipoId}}` | **`201 Created`** con préstamo en estado `ACTIVO` y equipo en estado `PRESTADO`. | **Captura 11:** Préstamo registrado con 201 Created en Postman. |
| **12** | En React, hacer clic en **`↻ Actualizar lista`** | El equipo `UAM-LAP-500` cambia su insignia en la tabla a **`PRESTADO`** y aparece el préstamo activo abajo. | **Captura 12:** Tabla en React mostrando `UAM-LAP-500` en estado `PRESTADO` tras el préstamo en Postman. |
| **13** | `4. Rechazo de segundo préstamo activo del mismo equipo` (`POST /api/prestamos`) | **`409 Conflict`** indicando que el equipo ya se encuentra `PRESTADO`. | **Captura 13:** Rechazo 409 al intentar prestar por segunda vez el mismo equipo. |
| **14** | `7. Eliminación bloqueada por préstamo activo` (`DELETE /api/equipos/{{equipoId}}`) | **`409 Conflict`** indicando que no se permite eliminar un equipo con préstamo `ACTIVO`. | **Captura 14:** Rechazo 409 al intentar eliminar un equipo prestado. |
| **15** | `5. Devolución y recuperación del estado DISPONIBLE` (`PUT /api/prestamos/{{prestamoId}}/devolver`) | **`200 OK`** con préstamo `DEVUELTO` y equipo nuevamente `DISPONIBLE`. | **Captura 15:** Devolución 200 OK en Postman y verificación en React de que volvió a `DISPONIBLE`. |
| **16** | `6. Eliminación permitida` (`DELETE /api/equipos/{{equipoId}}`) | **`204 No Content`** (elimina limpio aunque tenga el préstamo histórico ya `DEVUELTO`). | **Captura 16:** Eliminación exitosa 204 No Content en Postman. |

---

### Bloque C: Validaciones de Datos Inválidos y Recursos Inexistentes (Punto 13)

| # | Solicitud en Postman | Resultado Esperado | Captura a tomar |
| :- | :--- | :--- | :--- |
| **17** | `13.1 Fecha de devolución anterior a préstamo` (`POST /api/prestamos`) | **`400 Bad Request`** indicando que la fecha prevista de devolución no puede ser anterior al préstamo. | **Captura 17:** Validación 400 Bad Request por fechas inválidas. |
| **18** | `13.2 Tipo de equipo o campos inválidos` (`POST /api/equipos`) | **`400 Bad Request`** indicando que solo se permiten `Computadora portátil`, `Proyector` o `Tableta`. | **Captura 18:** Validación 400 Bad Request por tipo inválido. |
| **19** | `13.3 Código patrimonial duplicado` (`POST /api/equipos` con `UAM-LAP-001`) | **`409 Conflict`** por código patrimonial ya registrado. | **Captura 19:** Respuesta 409 Conflict por código patrimonial duplicado. |
| **20** | `13.4 Consulta de recurso inexistente` (`GET /api/equipos/999999`) | **`404 Not Found`** indicando que no existe el equipo. | **Captura 20:** Respuesta 404 Not Found ante ID inexistente. |
