import React, { useState } from 'react';

/**
 * Tabla de equipos tecnológicos con código patrimonial, nombre, tipo y estado.
 * Incluye estados explícitos de carga, lista vacía y error, botón para actualizar
 * la lista desde la API y acciones administrativas según el rol.
 * Responsabilidad técnica: Integrante 4 (React, Axios y visualización).
 */
export default function EquiposTable({
  equipos,
  cargando,
  error,
  esAdmin,
  ultimaActualizacion,
  onActualizarLista,
  onCrearEquipo,
  onEditarEquipo,
  onEliminarEquipo,
  onPrestarRapido
}) {
  const [busqueda, setBusqueda] = useState('');
  const [filtroEstado, setFiltroEstado] = useState('TODOS');
  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [equipoEditando, setEquipoEditando] = useState(null);

  const [codigoPatrimonial, setCodigoPatrimonial] = useState('');
  const [nombre, setNombre] = useState('');
  const [tipo, setTipo] = useState('Computadora portátil');
  const [guardando, setGuardando] = useState(false);
  const [mensajeFormulario, setMensajeFormulario] = useState({ tipo: '', texto: '' });

  const equiposFiltrados = equipos.filter((eq) => {
    const coincideTexto =
      eq.codigoPatrimonial.toLowerCase().includes(busqueda.toLowerCase()) ||
      eq.nombre.toLowerCase().includes(busqueda.toLowerCase()) ||
      eq.tipo.toLowerCase().includes(busqueda.toLowerCase());
    const coincideEstado = filtroEstado === 'TODOS' || eq.estado === filtroEstado;
    return coincideTexto && coincideEstado;
  });

  const abrirNuevo = () => {
    setEquipoEditando(null);
    setCodigoPatrimonial('');
    setNombre('');
    setTipo('Computadora portátil');
    setMensajeFormulario({ tipo: '', texto: '' });
    setMostrarFormulario(true);
  };

  const abrirEdicion = (equipo) => {
    setEquipoEditando(equipo);
    setCodigoPatrimonial(equipo.codigoPatrimonial);
    setNombre(equipo.nombre);
    setTipo(equipo.tipo);
    setMensajeFormulario({ tipo: '', texto: '' });
    setMostrarFormulario(true);
  };

  const cancelarFormulario = () => {
    setMostrarFormulario(false);
    setEquipoEditando(null);
    setMensajeFormulario({ tipo: '', texto: '' });
  };

  const manejarGuardarEquipo = async (e) => {
    e.preventDefault();
    setGuardando(true);
    setMensajeFormulario({ tipo: '', texto: '' });
    try {
      const payload = {
        codigoPatrimonial: codigoPatrimonial.trim(),
        nombre: nombre.trim(),
        tipo
      };
      if (equipoEditando) {
        await onEditarEquipo(equipoEditando.id, payload);
      } else {
        await onCrearEquipo(payload);
      }
      setMostrarFormulario(false);
      setEquipoEditando(null);
    } catch (err) {
      const texto =
        err.response?.data?.message ||
        'No se pudo guardar el equipo. Verifique los campos y permisos.';
      setMensajeFormulario({ tipo: 'error', texto });
    } finally {
      setGuardando(false);
    }
  };

  return (
    <section className="panel-card">
      <div className="panel-header">
        <div>
          <h2>Inventario de Equipos Tecnológicos</h2>
          <p className="panel-subtitle">
            Datos en tiempo real desde SQL Server (`GET /api/equipos`)
            {ultimaActualizacion ? ` • Última sincronización: ${ultimaActualizacion}` : ''}
          </p>
        </div>

        <div className="panel-actions">
          <button
            type="button"
            className="btn btn-secondary"
            onClick={onActualizarLista}
            disabled={cargando}
          >
            {cargando ? 'Actualizando...' : '↻ Actualizar lista'}
          </button>

          {esAdmin && (
            <button type="button" className="btn btn-primary" onClick={abrirNuevo}>
              + Nuevo equipo
            </button>
          )}
        </div>
      </div>

      {/* Formulario de Creación / Edición para ADMIN */}
      {esAdmin && mostrarFormulario && (
        <form className="inline-form" onSubmit={manejarGuardarEquipo}>
          <h3>{equipoEditando ? `Editar Equipo #${equipoEditando.id}` : 'Registrar Nuevo Equipo'}</h3>

          {mensajeFormulario.texto && (
            <div className="alert alert-danger">{mensajeFormulario.texto}</div>
          )}

          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="codigoPatrimonial">Código patrimonial único *</label>
              <input
                id="codigoPatrimonial"
                type="text"
                placeholder="Ej: UAM-LAP-003"
                value={codigoPatrimonial}
                onChange={(e) => setCodigoPatrimonial(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="nombreEquipo">Nombre del equipo *</label>
              <input
                id="nombreEquipo"
                type="text"
                placeholder="Ej: Laptop HP EliteBook 840"
                value={nombre}
                onChange={(e) => setNombre(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="tipoEquipo">Tipo de equipo *</label>
              <select
                id="tipoEquipo"
                value={tipo}
                onChange={(e) => setTipo(e.target.value)}
              >
                <option value="Computadora portátil">Computadora portátil</option>
                <option value="Proyector">Proyector</option>
                <option value="Tableta">Tableta</option>
              </select>
            </div>
          </div>

          <div className="form-buttons">
            <button type="submit" className="btn btn-primary" disabled={guardando}>
              {guardando ? 'Guardando...' : equipoEditando ? 'Guardar cambios' : 'Crear equipo'}
            </button>
            <button type="button" className="btn btn-outline" onClick={cancelarFormulario}>
              Cancelar
            </button>
          </div>
        </form>
      )}

      {/* Controles de búsqueda y filtro */}
      <div className="filter-bar">
        <input
          type="search"
          className="search-input"
          placeholder="Buscar por código patrimonial, nombre o tipo..."
          value={busqueda}
          onChange={(e) => setBusqueda(e.target.value)}
        />

        <div className="filter-pills">
          {['TODOS', 'DISPONIBLE', 'PRESTADO'].map((estado) => (
            <button
              key={estado}
              type="button"
              className={`pill-btn ${filtroEstado === estado ? 'active' : ''}`}
              onClick={() => setFiltroEstado(estado)}
            >
              {estado === 'TODOS' ? 'Todos' : estado}
            </button>
          ))}
        </div>
      </div>

      {/* 1. Estado de Error */}
      {error && (
        <div className="state-box state-error" role="alert">
          <h3>Error al consultar los equipos</h3>
          <p>{error}</p>
          <button type="button" className="btn btn-primary" onClick={onActualizarLista}>
            Reintentar consulta
          </button>
        </div>
      )}

      {/* 2. Estado de Carga */}
      {cargando && !error && (
        <div className="state-box state-loading" role="status">
          <div className="spinner" />
          <p>Cargando equipos tecnológicos desde la API protegida...</p>
        </div>
      )}

      {/* 3. Estado de Lista Vacía */}
      {!cargando && !error && equiposFiltrados.length === 0 && (
        <div className="state-box state-empty">
          <h3>No se encontraron equipos</h3>
          <p>
            {equipos.length === 0
              ? 'Actualmente no existen equipos registrados en la base de datos.'
              : 'Ningún equipo coincide con los criterios de búsqueda actuales.'}
          </p>
        </div>
      )}

      {/* 4. Tabla de Equipos */}
      {!cargando && !error && equiposFiltrados.length > 0 && (
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Código Patrimonial</th>
                <th>Nombre del Equipo</th>
                <th>Tipo</th>
                <th>Estado</th>
                {esAdmin && <th className="text-right">Acciones (ADMIN)</th>}
              </tr>
            </thead>
            <tbody>
              {equiposFiltrados.map((equipo) => (
                <tr key={equipo.id}>
                  <td data-label="ID">#{equipo.id}</td>
                  <td data-label="Código Patrimonial">
                    <span className="code-chip">{equipo.codigoPatrimonial}</span>
                  </td>
                  <td data-label="Nombre">{equipo.nombre}</td>
                  <td data-label="Tipo">{equipo.tipo}</td>
                  <td data-label="Estado">
                    <span
                      className={`status-badge ${
                        equipo.estado === 'DISPONIBLE' ? 'status-available' : 'status-loaned'
                      }`}
                    >
                      {equipo.estado}
                    </span>
                  </td>
                  {esAdmin && (
                    <td data-label="Acciones" className="actions-cell">
                      {equipo.estado === 'DISPONIBLE' && (
                        <button
                          type="button"
                          className="btn btn-sm btn-success"
                          onClick={() => onPrestarRapido(equipo)}
                        >
                          Prestar
                        </button>
                      )}
                      <button
                        type="button"
                        className="btn btn-sm btn-outline"
                        onClick={() => abrirEdicion(equipo)}
                      >
                        Editar
                      </button>
                      <button
                        type="button"
                        className="btn btn-sm btn-danger"
                        onClick={() => onEliminarEquipo(equipo)}
                      >
                        Eliminar
                      </button>
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
