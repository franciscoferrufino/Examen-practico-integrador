import axios from 'axios';

const API_BASE_URL = import.meta.env.VITE_API_URL || 'http://localhost:8080/api';

const STORAGE_KEY = 'tecnouam_session';

export function obtenerSesionGuardada() {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const sesion = JSON.parse(raw);
    if (sesion.expiresAt && Date.now() >= sesion.expiresAt) {
      localStorage.removeItem(STORAGE_KEY);
      return { expirada: true };
    }
    return sesion;
  } catch {
    localStorage.removeItem(STORAGE_KEY);
    return null;
  }
}

export function guardarSesion(datosLogin) {
  const expiresAt = Date.now() + (datosLogin.expiresInMs || 3600000);
  const sesion = {
    token: datosLogin.token,
    username: datosLogin.username,
    nombreCompleto: datosLogin.nombreCompleto,
    rol: datosLogin.rol,
    expiresAt
  };
  localStorage.setItem(STORAGE_KEY, JSON.stringify(sesion));
  return sesion;
}

export function limpiarSesion() {
  localStorage.removeItem(STORAGE_KEY);
}

const axiosClient = axios.create({
  baseURL: API_BASE_URL,
  headers: {
    'Content-Type': 'application/json'
  }
});

// Interceptor de solicitud: adjunta el JWT en Authorization: Bearer <token>
axiosClient.interceptors.request.use(
  (config) => {
    const sesion = obtenerSesionGuardada();
    if (sesion && sesion.token) {
      config.headers.Authorization = `Bearer ${sesion.token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Interceptor de respuesta: detecta 401 (sesión vencida o token inválido)
let onSessionExpiredCallback = null;

export function registrarManejadorSesionVencida(callback) {
  onSessionExpiredCallback = callback;
}

axiosClient.interceptors.response.use(
  (response) => response,
  (error) => {
    const status = error.response?.status;
    const url = error.config?.url || '';
    if (status === 401 && !url.includes('/auth/login')) {
      limpiarSesion();
      if (onSessionExpiredCallback) {
        onSessionExpiredCallback(
          'Su sesión ha vencido o el token JWT ya no es válido. Por favor, inicie sesión nuevamente.'
        );
      }
    }
    return Promise.reject(error);
  }
);

export default axiosClient;
