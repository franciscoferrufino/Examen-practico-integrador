import React, { useState, useEffect } from 'react';

/**
 * Panel funcional para consultar préstamos, registrar un préstamo nuevo y registrar devoluciones.
 */
export default function PrestamosPanel({
  prestamos,
  equiposDisponibles,
  equipoPreseleccionado,
  esAdmin,
  cargando,
  onRegistrarPrestamo,
  onDevolverPrestamo,
  onLimpiarPreseleccion
}) {
  const hoy = new Date().toISOString().split('T')[0];

  const [equipoId, setEquipoId] = useState('');
  const [nombreSolicitante, setNombreSolicitante] = useState('');
  const [fechaPrestamo, setFechaPrestamo] = useState(hoy);
  const [fechaDevolucionPrevista, setFechaDevolucionPrevista] = useState(hoy);
  const [enviando, setEnviando] = useState(false);
  const [errorForm, setErrorForm] = useState('');

  useEffect(() => {
    if (equipoPreseleccionado) {
      setEquipoId(String(equipoPreseleccionado.id));
    } else if (!equipoId && equiposDisponibles.length > 0) {
      setEquipoId(String(equiposDisponibles[0].id));
    }
  }, [equipoPreseleccionado, equiposDisponibles]);

  const manejarCrearPrestamo = async (e) => {
    e.preventDefault();
    setErrorForm('');

    if (!equipoId) {
      setErrorForm('Seleccione un equipo disponible.');
      return;
    }

    setEnviando(true);
    try {
      await onRegistrarPrestamo({
        equipoId: Number(equipoId),
        nombreSolicitante: nombreSolicitante.trim(),
        fechaPrestamo,
        fechaDevolucionPrevista
      });
      setNombreSolicitante('');
      if (onLimpiarPreseleccion) onLimpiarPreseleccion();
    } catch (err) {
      setErrorForm(
        err.response?.data?.message ||
          'No se pudo registrar el préstamo. Verifique que las fechas sean válidas y el equipo esté disponible.'
      );
    } finally {
      setEnviando(false);
    }
  };

  return (
    <section className="panel-card">
      <div className="panel-header">
        <div>
          <h2>Control de Préstamos y Devoluciones</h2>
          <p className="panel-subtitle">
            Registro transaccional de préstamos (`POST /api/prestamos`) y devoluciones (`PUT /api/prestamos/&#123;id&#125;/devolver`)
          </p>
        </div>
      </div>

      {esAdmin && (
        <form className="inline-form" onSubmit={manejarCrearPrestamo}>
          <h3>Registrar Nuevo Préstamo</h3>

          {errorForm && <div className="alert alert-danger">{errorForm}</div>}

          <div className="form-grid">
            <div className="form-group">
              <label htmlFor="equipoPrestamo">Equipo a prestar *</label>
              <select
                id="equipoPrestamo"
                value={equipoId}
                onChange={(e) => setEquipoId(e.target.value)}
                required
              >
                <option value="">-- Seleccione un equipo disponible --</option>
                {equiposDisponibles.map((eq) => (
                  <option key={eq.id} value={eq.id}>
                    {eq.codigoPatrimonial} - {eq.nombre} ({eq.tipo})
                  </option>
                ))}
              </select>
            </div>

            <div className="form-group">
              <label htmlFor="nombreSolicitante">Nombre del instructor solicitante *</label>
              <input
                id="nombreSolicitante"
                type="text"
                placeholder="Ej: Ing. Laura Castillo (Aula A-102)"
                value={nombreSolicitante}
                onChange={(e) => setNombreSolicitante(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="fechaPrestamo">Fecha de préstamo *</label>
              <input
                id="fechaPrestamo"
                type="date"
                value={fechaPrestamo}
                onChange={(e) => setFechaPrestamo(e.target.value)}
                required
              />
            </div>

            <div className="form-group">
              <label htmlFor="fechaDevolucionPrevista">Fecha prevista de devolución *</label>
              <input
                id="fechaDevolucionPrevista"
                type="date"
                value={fechaDevolucionPrevista}
                onChange={(e) => setFechaDevolucionPrevista(e.target.value)}
                required
              />
            </div>
          </div>

          <div className="form-buttons">
            <button
              type="submit"
              className="btn btn-primary"
              disabled={enviando || equiposDisponibles.length === 0}
            >
              {enviando ? 'Registrando préstamo...' : 'Confirmar préstamo'}
            </button>
          </div>
        </form>
      )}

      {!cargando && prestamos.length === 0 && (
        <div className="state-box state-empty">
          <h3>No hay préstamos registrados</h3>
          <p>Aún no se han registrado préstamos en el sistema.</p>
        </div>
      )}

      {prestamos.length > 0 && (
        <div className="table-responsive">
          <table className="data-table">
            <thead>
              <tr>
                <th>ID</th>
                <th>Equipo</th>
                <th>Solicitante</th>
                <th>Fecha Préstamo</th>
                <th>Devolución Prevista</th>
                <th>Estado</th>
                {esAdmin && <th className="text-right">Acción</th>}
              </tr>
            </thead>
            <tbody>
              {prestamos.map((p) => (
                <tr key={p.id}>
                  <td data-label="ID">#{p.id}</td>
                  <td data-label="Equipo">
                    <span className="code-chip">{p.equipo?.codigoPatrimonial}</span>{' '}
                    <span>{p.equipo?.nombre}</span>
                  </td>
                  <td data-label="Solicitante">{p.nombreSolicitante}</td>
                  <td data-label="Fecha Préstamo">{p.fechaPrestamo}</td>
                  <td data-label="Devolución Prevista">{p.fechaDevolucionPrevista}</td>
                  <td data-label="Estado">
                    <span
                      className={`status-badge ${
                        p.estado === 'ACTIVO' ? 'status-loaned' : 'status-available'
                      }`}
                    >
                      {p.estado}
                    </span>
                  </td>
                  {esAdmin && (
                    <td data-label="Acción" className="actions-cell">
                      {p.estado === 'ACTIVO' ? (
                        <button
                          type="button"
                          className="btn btn-sm btn-primary"
                          onClick={() => onDevolverPrestamo(p)}
                        >
                          Registrar devolución
                        </button>
                      ) : (
                        <span className="muted-label">
                          Devuelto {p.fechaDevolucionReal ? `(${p.fechaDevolucionReal})` : ''}
                        </span>
                      )}
                    </td>
                  )}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </section>
  );
}
