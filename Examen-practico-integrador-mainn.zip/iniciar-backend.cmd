@echo off
title TecnoUAM - Backend Spring Boot (Puerto 8080)
echo ============================================================================
echo   TECNO-UAM: INICIANDO BACKEND SPRING BOOT + SQL SERVER (PUERTO 8080)
echo ============================================================================
cd /d "%~dp0backend"
call .\mvnw.cmd spring-boot:run
pause

