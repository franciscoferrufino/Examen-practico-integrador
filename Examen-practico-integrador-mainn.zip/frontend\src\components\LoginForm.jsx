import React, { useState } from 'react';
import axiosClient from '../api/axiosClient';

/**
 * Componente funcional de Inicio de Sesión conectado a POST /api/auth/login.
 * Responsabilidad técnica: Integrante 4 (React, Axios y visualización).
 */
export default function LoginForm({ onLoginSuccess, mensajeSesionVencida }) {
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [cargando, setCargando] = useState(false);
  const [error, setError] = useState('');

  const manejarEnvio = async (e) => {
    e.preventDefault();
    setError('');

    if (!username.trim() || !password.trim()) {
      setError('Por favor ingrese su usuario y contraseña.');
      return;
    }

    setCargando(true);
    try {
      const respuesta = await axiosClient.post('/auth/login', {
        username: username.trim(),
        password
      });
      onLoginSuccess(respuesta.data);
    } catch (err) {
      const msg =
        err.response?.data?.message ||
        (err.response?.status === 401
          ? 'Usuario o contraseña incorrectos (HTTP 401).'
          : 'No se pudo conectar con el servidor de TecnoUAM. Verifique que el backend esté en ejecución en el puerto 8080.');
      setError(msg);
    } finally {
      setCargando(false);
    }
  };

  const completarCuentaPrueba = (user, pass) => {
    setUsername(user);
    setPassword(pass);
    setError('');
  };

  return (
    <div className="login-wrapper">
      <div className="login-card">
        <div className="login-brand">
          <span className="brand-badge">UNIVERSIDAD AMERICANA • UAM</span>
          <h1>Centro de Capacitación TecnoUAM</h1>
          <p>Sistema de Préstamo de Equipos Tecnológicos</p>
        </div>

        {mensajeSesionVencida && (
          <div className="alert alert-warning" role="alert">
            <strong>Sesión finalizada:</strong> {mensajeSesionVencida}
          </div>
        )}

        {error && (
          <div className="alert alert-danger" role="alert">
            <strong>Error de autenticación:</strong> {error}
          </div>
        )}

        <form onSubmit={manejarEnvio} className="login-form">
          <div className="form-group">
            <label htmlFor="username">Nombre de usuario</label>
            <input
              id="username"
              type="text"
              placeholder="Ej: admin o user"
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              disabled={cargando}
              autoComplete="username"
            />
          </div>

          <div className="form-group">
            <label htmlFor="password">Contraseña</label>
            <input
              id="password"
              type="password"
              placeholder="Ingrese su contraseña"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              disabled={cargando}
              autoComplete="current-password"
            />
          </div>

          <button type="submit" className="btn btn-primary btn-block" disabled={cargando}>
            {cargando ? 'Verificando credenciales...' : 'Iniciar sesión'}
          </button>
        </form>

        <div className="quick-credentials">
          <p className="quick-title">Cuentas de prueba para evaluación:</p>
          <div className="quick-buttons">
            <button
              type="button"
              className="btn btn-outline"
              onClick={() => completarCuentaPrueba('admin', 'admin123')}
            >
              Cargar ADMIN (admin / admin123)
            </button>
            <button
              type="button"
              className="btn btn-outline"
              onClick={() => completarCuentaPrueba('user', 'user123')}
            >
              Cargar USER (user / user123)
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
