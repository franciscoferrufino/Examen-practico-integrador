# Reporte de Evidencias Reales de Ejecución (SQL Server + Spring Boot + React)

**Fecha de verificación:** 28/10/2026  
**Servidor Backend:** `http://localhost:8080` (Spring Boot 3.5.0 + Java 21)  
**Motor de Base de Datos:** Microsoft SQL Server 2022 Developer Edition (`localhost:1433`, BD `TecnoUAM`)  
**Servidor Frontend:** `http://localhost:5173` (React 18 + Vite + Axios)

---

## 1. Evidencia de Tablas y Datos en SQL Server (`TecnoUAM`)

Resultado real de la consulta en `sqlcmd` sobre `TecnoUAM`:

```text
-- Tabla dbo.usuarios (Contraseñas cifradas con BCrypt)
id | username   | nombre_completo                       | rol
---+------------+---------------------------------------+------
1  | admin      | Administrador TecnoUAM                | ADMIN
2  | user       | Instructor Consultor TecnoUAM         | USER
3  | instructor | Prof. Carlos Mendoza (Instructor UAM) | USER

-- Tabla dbo.equipos
id | codigo_patrimonial | nombre                              | tipo                 | estado
---+--------------------+-------------------------------------+----------------------+-----------
1  | UAM-LAP-001        | Laptop Dell Latitude 5540 Core i7   | Computadora portátil | DISPONIBLE
2  | UAM-LAP-002        | MacBook Air M2 13 Pulgadas          | Computadora portátil | PRESTADO
3  | UAM-PRO-001        | Proyector Epson PowerLite E20 3400L | Proyector            | DISPONIBLE
4  | UAM-PRO-002        | Proyector BenQ MH560 Full HD        | Proyector            | DISPONIBLE
5  | UAM-TAB-001        | iPad Air 5ta Generación 64GB        | Tableta              | DISPONIBLE
6  | UAM-TAB-002        | Samsung Galaxy Tab S9 FE            | Tableta              | PRESTADO

-- Tabla dbo.prestamos
id | equipo_id | nombre_solicitante                     | fecha_prestamo | fecha_devolucion_prevista | estado
---+-----------+----------------------------------------+----------------+---------------------------+---------
1  | 3         | MSc. Roberto Blandón (Aula B-204)      | 2026-10-20     | 2026-10-22                | DEVUELTO
2  | 2         | Ing. María Fernanda Solís (Lab Redes)  | 2026-10-27     | 2026-10-30                | ACTIVO
3  | 6         | Dr. Alejandro Vega (Auditorio Central) | 2026-10-28     | 2026-10-31                | ACTIVO
```

---

## 2. Evidencia de los 13 Casos Obligatorios de la API REST

### Caso 1: Login ADMIN y USER (`POST /api/auth/login` -> `200 OK`)
**Solicitud:**
```json
{
  "username": "admin",
  "password": "admin123"
}
```
**Respuesta (`200 OK`):**
```json
{
  "token": "eyJhbGciOiJIUzI1NiJ9...",
  "tokenType": "Bearer",
  "username": "admin",
  "nombreCompleto": "Administrador TecnoUAM",
  "rol": "ADMIN",
  "expiresInMs": 3600000
}
```

### Caso 8: Consulta sin token (`GET /api/equipos` -> `401 Unauthorized`)
**Respuesta (`401 Unauthorized`):**
```json
{
  "timestamp": "2026-10-28T17:18:35",
  "status": 401,
  "error": "Unauthorized",
  "message": "No autenticado: falta el token JWT, ha expirado o es inválido.",
  "path": "/api/equipos"
}
```

### Caso 9: Consulta con rol USER (`GET /api/equipos` -> `200 OK`)
**Respuesta (`200 OK`):** Retorna los 6 equipos registrados en SQL Server.

### Caso 10: Creación con rol USER (`POST /api/equipos` -> `403 Forbidden`)
**Respuesta (`403 Forbidden`):**
```json
{
  "timestamp": "2026-10-28T17:18:36",
  "status": 403,
  "error": "Forbidden",
  "message": "Acceso denegado: su rol actual no tiene permisos para realizar esta acción. Se requiere rol ADMIN.",
  "path": "/api/equipos"
}
```

### Caso 2 y 11: Alta válida con ADMIN (`POST /api/equipos` -> `201 Created`)
**Solicitud:**
```json
{
  "codigoPatrimonial": "UAM-LAP-500",
  "nombre": "Laptop ASUS ExpertBook B5 OLED",
  "tipo": "Computadora portátil"
}
```
**Respuesta (`201 Created`):**
```json
{
  "id": 7,
  "codigoPatrimonial": "UAM-LAP-500",
  "nombre": "Laptop ASUS ExpertBook B5 OLED",
  "tipo": "Computadora portátil",
  "estado": "DISPONIBLE"
}
```

### Caso 3: Registro de préstamo (`POST /api/prestamos` -> `201 Created` y cambio a `PRESTADO`)
**Respuesta (`201 Created`):**
```json
{
  "id": 4,
  "equipoId": 7,
  "equipo": {
    "id": 7,
    "codigoPatrimonial": "UAM-LAP-500",
    "nombre": "Laptop ASUS ExpertBook B5 OLED (Actualizada 32GB)",
    "tipo": "Computadora portátil",
    "estado": "PRESTADO"
  },
  "nombreSolicitante": "MSc. Gabriel Rivas (Laboratorio C-105)",
  "fechaPrestamo": "2026-10-28",
  "fechaDevolucionPrevista": "2026-10-31",
  "fechaDevolucionReal": null,
  "estado": "ACTIVO"
}
```

### Caso 4: Rechazo de segundo préstamo activo del mismo equipo (`409 Conflict`)
**Respuesta (`409 Conflict`):**
```json
{
  "timestamp": "2026-10-28T17:18:38",
  "status": 409,
  "error": "Conflict",
  "message": "No se puede prestar el equipo 'UAM-LAP-500' (Laptop ASUS ExpertBook B5 OLED (Actualizada 32GB)) porque ya se encuentra PRESTADO.",
  "path": "/api/prestamos"
}
```

### Caso 7: Eliminación bloqueada por préstamo activo (`DELETE /api/equipos/7` -> `409 Conflict`)
**Respuesta (`409 Conflict`):**
```json
{
  "timestamp": "2026-10-28T17:18:39",
  "status": 409,
  "error": "Conflict",
  "message": "No se permite eliminar el equipo 'UAM-LAP-500' porque tiene un préstamo ACTIVO.",
  "path": "/api/equipos/7"
}
```

### Caso 5: Devolución y recuperación del estado DISPONIBLE (`PUT /api/prestamos/4/devolver` -> `200 OK`)
**Respuesta (`200 OK`):**
```json
{
  "id": 4,
  "equipoId": 7,
  "equipo": {
    "id": 7,
    "codigoPatrimonial": "UAM-LAP-500",
    "nombre": "Laptop ASUS ExpertBook B5 OLED (Actualizada 32GB)",
    "tipo": "Computadora portátil",
    "estado": "DISPONIBLE"
  },
  "nombreSolicitante": "MSc. Gabriel Rivas (Laboratorio C-105)",
  "fechaPrestamo": "2026-10-28",
  "fechaDevolucionPrevista": "2026-10-31",
  "fechaDevolucionReal": "2026-10-28",
  "estado": "DEVUELTO"
}
```

### Caso 6: Eliminación permitida con préstamo ya devuelto (`DELETE /api/equipos/7` -> `204 No Content`)
**Respuesta:** `HTTP 204 No Content` (Sin cuerpo, eliminando previamente el historial `DEVUELTO` en la misma transacción sin violar la clave foránea).

### Casos 12 y 13: Login incorrecto (`401`), Fechas/Campos inválidos (`400`), Código duplicado (`409`) y Recurso inexistente (`404`)
- `POST /api/auth/login` con clave errónea → **`401 Unauthorized`**
- `POST /api/prestamos` con `fechaDevolucionPrevista < fechaPrestamo` → **`400 Bad Request`**
- `POST /api/equipos` con tipo `"Televisor"` → **`400 Bad Request`**
- `POST /api/equipos` con código `"UAM-LAP-001"` ya existente → **`409 Conflict`**
- `GET /api/equipos/999999` → **`404 Not Found`**

