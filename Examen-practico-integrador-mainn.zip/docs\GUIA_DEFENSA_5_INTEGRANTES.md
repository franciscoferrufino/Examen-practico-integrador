# Guía de Defensa Técnica para los 5 Integrantes — TecnoUAM

Esta guía prepara a cada uno de los cinco integrantes del equipo para responder con precisión las preguntas del docente durante el **Reto 5 (Defensa técnica colaborativa)**.

---

## Parte 1: Distribución de Responsabilidades por Integrante

### Integrante 1: Entidades, Relaciones JPA y Base de Datos SQL Server
- **Archivos clave:**
  - [`init-tecnouam.sql`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/database/init-tecnouam.sql)
  - [`Equipo.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/model/Equipo.java)
  - [`Prestamo.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/model/Prestamo.java)
  - [`EquipoRepository.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/repository/EquipoRepository.java)
- **Qué debe explicar:**
  - En SQL Server creamos la base `TecnoUAM` con tres tablas: `equipos`, `prestamos` y `usuarios`.
  - En `Equipo`, el campo `codigo_patrimonial` tiene restricción `UNIQUE` (`@Column(unique = true, nullable = false)`).
  - La relación entre `Prestamo` y `Equipo` es **Muchos a Uno (`@ManyToOne`)**: un equipo puede tener muchos préstamos a lo largo del tiempo (históricos devueltos), pero cada registro de préstamo pertenece a un único equipo mediante la clave foránea `equipo_id` (`@JoinColumn(name = "equipo_id", nullable = false)`).
  - En `EquipoRepository` implementamos `findByIdWithLock` con `@Lock(LockModeType.PESSIMISTIC_WRITE)` y en SQL Server el índice único filtrado `UX_prestamos_equipo_activo` para impedir dos préstamos activos simultáneos sobre el mismo equipo.

---

### Integrante 2: Servicios, CRUD, Reglas de Negocio y Manejo de Errores
- **Archivos clave:**
  - [`EquipoService.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/service/EquipoService.java)
  - [`PrestamoService.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/service/PrestamoService.java)
  - [`EquipoController.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/controller/EquipoController.java)
  - [`PrestamoController.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/controller/PrestamoController.java)
  - [`GlobalExceptionHandler.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/exception/GlobalExceptionHandler.java)
- **Qué debe explicar:**
  - Toda la lógica de negocio vive en la capa `@Service`, nunca suelta en los controladores.
  - Al registrar un préstamo (`PrestamoService.registrarPrestamo`), se valida que `fechaDevolucionPrevista >= fechaPrestamo` (si no, lanza `BadRequestException` -> `400`). Luego se bloquea el equipo con `findByIdWithLock`, se verifica que esté `DISPONIBLE` (si está `PRESTADO`, lanza `BusinessConflictException` -> `409`), se cambia el equipo a `PRESTADO` y se guarda el préstamo como `ACTIVO` dentro de un mismo método `@Transactional`.
  - En `EquipoService.actualizarEquipo` (`PUT /api/equipos/{id}`), se impide que alguien edite manualmente el estado del equipo contradiciendo sus préstamos activos (por ejemplo, pasar a `DISPONIBLE` un equipo que tiene un préstamo `ACTIVO`).
  - `GlobalExceptionHandler` (`@RestControllerAdvice`) centraliza las respuestas de error devolviendo siempre JSON estructurado con los códigos `400`, `404` y `409`.

---

### Integrante 3: Spring Security, JWT y Control de Acceso por Roles
- **Archivos clave:**
  - [`SecurityConfig.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/security/SecurityConfig.java)
  - [`JwtService.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/security/JwtService.java)
  - [`JwtAuthenticationFilter.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/security/JwtAuthenticationFilter.java)
  - [`RestAuthenticationEntryPoint.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/security/RestAuthenticationEntryPoint.java)
  - [`RestAccessDeniedHandler.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/security/RestAccessDeniedHandler.java)
  - [`AuthController.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/controller/AuthController.java)
- **Qué debe explicar:**
  - La API es **Stateless** (`SessionCreationPolicy.STATELESS`): el servidor no guarda sesiones en memoria.
  - Las contraseñas nunca se guardan en texto plano; se cifran con `BCryptPasswordEncoder`.
  - Los secretos (`JWT_SECRET`, `DB_PASSWORD`) se leen desde variables de entorno (`.env` excluido en `.gitignore`).
  - En `SecurityConfig`, las rutas `GET /api/equipos/**` y `GET /api/prestamos/**` permiten `hasAnyRole("USER", "ADMIN")`, mientras que `POST`, `PUT` y `DELETE` exigen `hasRole("ADMIN")`.

---

### Integrante 4: Frontend React, Componentes Funcionales y Axios
- **Archivos clave:**
  - [`axiosClient.js`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/frontend/src/api/axiosClient.js)
  - [`App.jsx`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/frontend/src/App.jsx)
  - [`LoginForm.jsx`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/frontend/src/components/LoginForm.jsx)
  - [`EquiposTable.jsx`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/frontend/src/components/EquiposTable.jsx)
- **Qué debe explicar:**
  - Cómo se autentica `LoginForm` enviando `POST /api/auth/login` y almacenando el JWT en `localStorage`.
  - Cómo el interceptor de solicitudes de `axiosClient.js` agrega automáticamente `Authorization: Bearer <token>` en cada petición hacia el backend.
  - Cómo `App.jsx` usa `useState` (para almacenar `equipos`, `cargando`, `error`, `sesion`) y `useEffect` (para disparar la consulta protegida `GET /api/equipos` al iniciar sesión).
  - Cómo `EquiposTable.jsx` maneja los 4 estados visuales: cargando (`spinner`), error de red/servidor, lista vacía y tabla con datos reales, además del botón **`↻ Actualizar lista`** que vuelve a invocar `GET /api/equipos`.

---

### Integrante 5: Pruebas Postman, Pruebas Automatizadas e Integración
- **Archivos clave:**
  - [`TecnoUAM_Coleccion_Postman.json`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/postman/TecnoUAM_Coleccion_Postman.json)
  - [`TecnoUAM_Entorno_Postman.json`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/postman/TecnoUAM_Entorno_Postman.json)
  - [`TecnoUamIntegrationTests.java`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/test/java/edu/uam/tecnouam/TecnoUamIntegrationTests.java)
- **Qué debe explicar:**
  - Cómo están organizados los 13 casos de prueba en Postman usando variables dinámicas (`{{baseUrl}}`, `{{adminToken}}`, `{{userToken}}`, `{{equipoId}}`, `{{prestamoId}}`) sin guardar contraseñas en el repositorio.
  - Cómo al crear o prestar un equipo en Postman y presionar **`↻ Actualizar lista`** en React se evidencia la persistencia real en SQL Server.
  - Cómo la suite `TecnoUamIntegrationTests` verifica automáticamente permisos `401`/`403`, reglas de negocio `400`/`404`/`409` y solicitudes concurrentes simultáneas.

---

## Parte 2: Respuestas Sencillas a las 4 Preguntas Clave de la Defensa

### 1. ¿Cómo funciona el flujo completo del JWT en el sistema?
1. **Inicio de sesión:** El usuario envía `username` y `password` a `POST /api/auth/login`.
2. **Verificación BCrypt:** `AuthenticationManager` compara la contraseña contra el hash BCrypt almacenado en la tabla `usuarios` de SQL Server.
3. **Emisión y firma:** Si es válida, `JwtService` genera un token JWT que incluye el usuario (`sub`), su rol (`rol`), fecha de emisión (`iat`) y fecha de expiración (`exp`), y lo firma criptográficamente con `HMAC-SHA256` usando la clave secreta `JWT_SECRET`.
4. **Envío en cada consulta:** El frontend React (o Postman) guarda el token y lo envía en el encabezado HTTP `Authorization: Bearer <token>`.
5. **Validación sin sesiones:** En cada petición, `JwtAuthenticationFilter` intercepta el encabezado, valida la firma y que no haya vencido, y carga los permisos (`ROLE_ADMIN` o `ROLE_USER`) en el `SecurityContextHolder` únicamente por la duración de esa petición.

### 2. ¿Cuál es la diferencia exacta entre HTTP 401 y HTTP 403?
- **`401 Unauthorized` (Falta de autenticación válida):** El sistema **no sabe quién es el cliente**. Ocurre cuando no se envía el encabezado `Authorization`, el token JWT está vencido/manipulado, o las credenciales en `/api/auth/login` son incorrectas. Lo maneja nuestro `RestAuthenticationEntryPoint`.
- **`403 Forbidden` (Falta de permisos / autorización):** El sistema **sí sabe quién es el cliente** (su token JWT es válido), pero **su rol no tiene permiso** para la operación solicitada. Por ejemplo, cuando el usuario con rol `USER` intenta hacer `POST /api/equipos`. Lo maneja nuestro `RestAccessDeniedHandler`.

### 3. ¿Cómo funciona la relación JPA entre `Equipo` y `Prestamo` y cómo se elimina un equipo con préstamos devueltos?
- En la clase `Prestamo` existe una relación `@ManyToOne` con `@JoinColumn(name = "equipo_id", nullable = false)`. Esto crea una clave foránea en la tabla `prestamos` que apunta a `equipos(id)`.
- Un equipo no puede eliminarse si tiene un préstamo `ACTIVO` (se rechaza con `409 Conflict`).
- Si el equipo está `DISPONIBLE` pero tuvo préstamos en el pasado que ya están en estado `DEVUELTO`, una eliminación directa en SQL fallaría por la clave foránea. Por eso, en `EquipoService.eliminarEquipo(id)`, dentro de una transacción `@Transactional`, primero verificamos que no existan préstamos `ACTIVO`, luego eliminamos sus registros históricos en estado `DEVUELTO` (`prestamoRepository.deleteByEquipoIdAndEstado(id, EstadoPrestamo.DEVUELTO)`) y finalmente eliminamos el equipo sin error de clave foránea.

### 4. ¿Por qué usamos `@Transactional` al prestar y al devolver un equipo?
- Porque prestar un equipo implica **dos operaciones de base de datos que deben cumplirse juntas o no cumplirse ninguna (atomicidad ACID)**:
  1. Cambiar el estado del registro en la tabla `equipos` a `PRESTADO` (o `DISPONIBLE` al devolver).
  2. Insertar o actualizar el registro en la tabla `prestamos` con estado `ACTIVO` (o `DEVUELTO`).
- Gracias a `@Transactional`, si ocurre cualquier fallo intermedio, Spring realiza un **rollback automático** de ambas tablas, garantizando que nunca quede un préstamo activo con un equipo que figure como disponible, ni viceversa.
