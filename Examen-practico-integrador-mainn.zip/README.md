# Sistema de Préstamo de Equipos Tecnológicos — TecnoUAM

**Universidad Americana (UAM) • Facultad de Ingeniería • Ingeniería de Sistemas**  
**Asignatura:** Servicios Web — Examen Práctico Integrador (Segundo Corte)  
**Caso:** Centro de Capacitación TecnoUAM

---

## 1. Descripción General

Solución cliente-servidor desarrollada desde cero para gestionar el inventario y préstamo de equipos tecnológicos (**Computadora portátil**, **Proyector** y **Tableta**) del Centro de Capacitación **TecnoUAM**.

### Arquitectura y Tecnologías
- **Backend (`backend/`):** Java 21, Spring Boot 3.5.0, Spring Data JPA, Spring Security 6, JSON Web Tokens (`JJWT 0.11.5`), Bean Validation y BCrypt.
- **Base de Datos (`database/`):** Microsoft SQL Server 2022 Developer Edition (`localhost:1433`, base de datos `TecnoUAM`). Incluye alternativa reproducible en memoria (`H2` en modo `MSSQLServer`) para la suite de pruebas automatizadas JUnit 5.
- **Frontend (`frontend/`):** React 18 (componentes funcionales, `useState`, `useEffect`), Vite y `Axios` con interceptores para inyección de JWT y detección de sesión vencida (`401`).
- **Colección Postman (`postman/`):** Colección y entorno sin secretos con los 13 escenarios obligatorios de validación y scripts de comprobación automática.

---

## 2. Estructura del Proyecto

```text
.
├── .env.example                           # Plantilla de variables de entorno sin secretos
├── .gitignore                             # Exclusión de .env, node_modules y target
├── README.md                              # Documentación principal de instalación y ejecución
├── database/
│   └── init-tecnouam.sql                  # Script T-SQL para crear BD TecnoUAM, tablas, índices y datos semilla
├── backend/
│   ├── pom.xml                            # Dependencias Maven (Spring Boot, JPA, Security, JWT, SQL Server)
│   ├── mvnw.cmd                           # Wrapper Maven con detección automática de JDK
│   ├── .env.example                       # Plantilla de variables de entorno para el backend
│   └── src/
│       ├── main/java/edu/uam/tecnouam/
│       │   ├── config/DataInitializer.java         # Inicializador reproducible de cuentas ADMIN y USER (BCrypt)
│       │   ├── controller/                         # AuthController, EquipoController, PrestamoController
│       │   ├── dto/                                # DTOs de entrada/salida y ApiErrorResponse
│       │   ├── exception/                          # GlobalExceptionHandler y excepciones HTTP 400, 404, 409
│       │   ├── model/                              # Entidades JPA: Equipo, Prestamo, Usuario y Enums
│       │   ├── repository/                         # Repositorios JPA con bloqueo pesimista (PESSIMISTIC_WRITE)
│       │   ├── security/                           # JwtService, JwtAuthenticationFilter, SecurityConfig, 401/403
│       │   └── service/                            # Reglas de negocio transaccionales (EquipoService, PrestamoService)
│       └── test/java/edu/uam/tecnouam/
│           └── TecnoUamIntegrationTests.java       # Pruebas automatizadas JUnit 5 + MockMvc (13 casos + concurrencia)
├── frontend/
│   ├── package.json
│   ├── vite.config.js
│   └── src/
│       ├── api/axiosClient.js             # Cliente Axios con interceptor Bearer JWT y manejo de 401
│       ├── components/
│       │   ├── LoginForm.jsx              # Inicio de sesión real conectado a POST /api/auth/login
│       │   ├── EquiposTable.jsx           # Tabla de equipos con estados de carga, lista vacía, error y recarga
│       │   └── PrestamosPanel.jsx         # Registro de préstamos y devoluciones
│       ├── App.jsx                        # Estado principal con useState y useEffect
│       └── App.css                        # Diseño responsivo para computadora y móvil
├── postman/
│   ├── TecnoUAM_Coleccion_Postman.json    # Colección Postman con las 13 pruebas funcionales y de seguridad
│   └── TecnoUAM_Entorno_Postman.json      # Entorno Postman sin secretos
└── docs/
    ├── GUIA_DEMOSTRACION_Y_CAPTURAS.md    # Orden paso a paso de pruebas y capturas requeridas
    └── GUIA_DEFENSA_5_INTEGRANTES.md      # Guía de defensa técnica por integrante y preguntas clave
```

---

## 3. Requisitos Previos

1. **Java JDK 17 o 21** (el script `backend\mvnw.cmd` detecta automáticamente el JDK 21 instalado en `C:\Program Files\JetBrains\IntelliJ IDEA 2025.1.1.1\jbr` si `JAVA_HOME` no está configurado).
2. **Microsoft SQL Server** ejecutándose en `localhost:1433` (verificado en este equipo: *SQL Server 2022 Developer Edition*).
3. **Node.js 18+** y **npm** (verificado en este equipo: *Node v24.15.0 / npm 11.12.1*).

---

## 4. Configuración de Base de Datos SQL Server

Ejecute el script `database/init-tecnouam.sql` desde **SQL Server Management Studio (SSMS)** o mediante `sqlcmd` en PowerShell:

```powershell
sqlcmd -S localhost -E -f 65001 -i ".\database\init-tecnouam.sql"
```

Este script realiza de forma idempotente:
1. Creación de la base de datos **`TecnoUAM`**.
2. Configuración del login SQL **`tecnouam_user`** con permisos `db_owner` sobre `TecnoUAM` para conexión TCP/IP en el puerto `1433`.
3. Creación de las tablas `dbo.usuarios`, `dbo.equipos` y `dbo.prestamos` con sus restricciones `UNIQUE`, `CHECK` y `FOREIGN KEY`.
4. Creación del índice único filtrado `UX_prestamos_equipo_activo` (`WHERE estado = 'ACTIVO'`) que refuerza a nivel de motor de base de datos que jamás existan dos préstamos activos para un mismo equipo.
5. Inserción de equipos y préstamos iniciales de demostración.

---

## 5. Variables de Entorno (`.env`)

El repositorio incluye `.env.example` sin secretos y excluye `.env` mediante `.gitignore`.  
Copie `.env.example` a `.env` (en la raíz y/o en `backend/.env`):

```powershell
Copy-Item .env.example .env
Copy-Item backend\.env.example backend\.env
```

Variables utilizadas por el backend:

| Variable | Descripción | Valor de ejemplo (`.env.example`) |
| :--- | :--- | :--- |
| `SERVER_PORT` | Puerto HTTP de Spring Boot | `8080` |
| `DB_URL` | Cadena JDBC SQL Server | `jdbc:sqlserver://localhost:1433;databaseName=TecnoUAM;encrypt=true;trustServerCertificate=true` |
| `DB_USERNAME` | Usuario SQL Server | `tecnouam_user` |
| `DB_PASSWORD` | Contraseña SQL Server | *(Definida localmente en `.env`)* |
| `JWT_SECRET` | Clave secreta HMAC-SHA256 (mínimo 32 caracteres) | *(Definida localmente en `.env`)* |
| `JWT_EXPIRATION_MS` | Tiempo de expiración del token JWT en milisegundos | `3600000` (1 hora) |
| `CORS_ALLOWED_ORIGINS` | Orígenes permitidos para React | `http://localhost:5173,http://localhost:3000` |
| `APP_ADMIN_USERNAME` / `APP_ADMIN_PASSWORD` | Credenciales iniciales ADMIN | `admin` / *(en `.env`)* |
| `APP_USER_USERNAME` / `APP_USER_PASSWORD` | Credenciales iniciales USER | `user` / *(en `.env`)* |

---

## 6. Cuentas de Prueba Reproducibles

Al iniciar el backend, el componente [`DataInitializer`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/config/DataInitializer.java) sincroniza automáticamente en SQL Server las cuentas de prueba con sus contraseñas cifradas mediante **BCrypt**:

| Rol | Usuario | Contraseña local (`.env`) | Permisos en el sistema |
| :--- | :--- | :--- | :--- |
| **`ADMIN`** | `admin` | `admin123` | Consultar, crear, actualizar y eliminar equipos; registrar préstamos y devoluciones. |
| **`USER`** | `user` | `user123` | Únicamente consultar equipos (`GET /api/equipos`) y préstamos (`GET /api/prestamos`). |
| **`USER`** | `instructor` | `user123` | Cuenta adicional de consulta para instructores. |

---

## 7. Comandos Exactos de Instalación y Ejecución

### Paso 1: Ejecutar pruebas automatizadas del Backend
```powershell
.\backend\mvnw.cmd -f .\backend\pom.xml test
```

### Paso 2: Iniciar el Backend Spring Boot (Puerto 8080)
```powershell
.\backend\mvnw.cmd -f .\backend\pom.xml spring-boot:run
```
La API quedará disponible en `http://localhost:8080`.

### Paso 3: Instalar e iniciar el Frontend React (Puerto 5173)
En una nueva terminal de PowerShell:
```powershell
npm install --prefix .\frontend
npm run dev --prefix .\frontend
```
Abra en el navegador `http://localhost:5173`.

---

## 8. Especificación de Endpoints REST y Códigos HTTP

| Método | Ruta | Roles Permitidos | Descripción | Códigos HTTP |
| :--- | :--- | :--- | :--- | :--- |
| `POST` | `/api/auth/login` | Público | Autentica credenciales y emite JWT firmado con vencimiento | `200`, `400`, `401` |
| `GET` | `/api/equipos` | `USER`, `ADMIN` | Lista todos los equipos tecnológicos | `200`, `401` |
| `GET` | `/api/equipos/{id}` | `USER`, `ADMIN` | Consulta el detalle de un equipo por ID | `200`, `401`, `404` |
| `POST` | `/api/equipos` | `ADMIN` | Crea un equipo nuevo (valida código único y tipo permitido) | `201`, `400`, `401`, `403`, `409` |
| `PUT` | `/api/equipos/{id}` | `ADMIN` | Actualiza un equipo e impide contradecir préstamos activos | `200`, `400`, `401`, `403`, `404`, `409` |
| `DELETE` | `/api/equipos/{id}` | `ADMIN` | Elimina un equipo solo si no tiene préstamos activos | `204`, `401`, `403`, `404`, `409` |
| `GET` | `/api/prestamos` | `USER`, `ADMIN` | Lista todos los préstamos con su equipo asociado | `200`, `401` |
| `POST` | `/api/prestamos` | `ADMIN` | Registra un préstamo y cambia el equipo a `PRESTADO` en una transacción | `201`, `400`, `401`, `403`, `404`, `409` |
| `PUT` | `/api/prestamos/{id}/devolver` | `ADMIN` | Registra la devolución y cambia el equipo a `DISPONIBLE` en una transacción | `200`, `401`, `403`, `404`, `409` |

---

## 9. Estrategia de Eliminación de Equipos con Préstamos Devueltos (Sin Errores de Clave Foránea)

La tabla `prestamos` mantiene una clave foránea (`FK_prestamos_equipo`) hacia `equipos(id)`.  
Para cumplir las reglas de negocio sin errores de integridad referencial:
1. Cuando se invoca `DELETE /api/equipos/{id}`, [`EquipoService.eliminarEquipo`](file:///c:/Users/USUARIO/Downloads/Examen%20práctico%20integrador/backend/src/main/java/edu/uam/tecnouam/service/EquipoService.java) adquiere un bloqueo pesimista sobre el equipo y verifica si existe algún préstamo con estado `ACTIVO` (`prestamoRepository.existsByEquipoIdAndEstado(id, EstadoPrestamo.ACTIVO)`).
2. **Si tiene un préstamo `ACTIVO`:** la operación se rechaza inmediatamente con **`409 Conflict`**.
3. **Si NO tiene préstamos `ACTIVO` pero sí préstamos históricos en estado `DEVUELTO`:** dentro de la misma transacción (`@Transactional`), el servicio elimina primero los registros en estado `DEVUELTO` (`prestamoRepository.deleteByEquipoIdAndEstado(id, EstadoPrestamo.DEVUELTO)`) y enseguida elimina el registro de `Equipo`, respondiendo **`204 No Content`** sin violar la restricción de clave foránea.

---

## 10. Flujo de Trabajo Git para los 5 Integrantes

Para reflejar aportes reales e identificables de los cinco estudiantes en el repositorio compartido:
1. **Integrante 1 (Entidades, JPA y SQL Server):** realizar commits sobre `database/init-tecnouam.sql`, `backend/.../model/` y `backend/.../repository/`.
2. **Integrante 2 (Servicios, CRUD y Excepciones):** realizar commits sobre `backend/.../dto/`, `backend/.../service/`, `backend/.../controller/EquipoController.java`, `PrestamoController.java` y `backend/.../exception/`.
3. **Integrante 3 (Spring Security, JWT y Roles):** realizar commits sobre `backend/.../security/`, `backend/.../controller/AuthController.java`, `backend/.../config/DataInitializer.java` y `.env.example`.
4. **Integrante 4 (Frontend React y Axios):** realizar commits sobre `frontend/`.
5. **Integrante 5 (Pruebas Postman, JUnit y Documentación):** realizar commits sobre `postman/`, `backend/src/test/` y `docs/`.
