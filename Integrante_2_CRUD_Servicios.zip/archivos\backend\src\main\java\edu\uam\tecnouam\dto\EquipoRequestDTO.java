package edu.uam.tecnouam.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Size;

/**
 * DTO de entrada para creación y actualización de equipos tecnológicos.
 */
public class EquipoRequestDTO {

    @NotBlank(message = "El código patrimonial es obligatorio.")
    @Size(max = 50, message = "El código patrimonial no puede exceder 50 caracteres.")
    private String codigoPatrimonial;

    @NotBlank(message = "El nombre del equipo es obligatorio.")
    @Size(max = 150, message = "El nombre del equipo no puede exceder 150 caracteres.")
    private String nombre;

    @NotBlank(message = "El tipo de equipo es obligatorio (Computadora portátil, Proyector o Tableta).")
    private String tipo;

    /**
     * Opcional al crear (por defecto DISPONIBLE).
     * Al actualizar, se valida que nunca contradiga los préstamos activos del equipo.
     */
    private String estado;

    public EquipoRequestDTO() {
    }

    public EquipoRequestDTO(String codigoPatrimonial, String nombre, String tipo, String estado) {
        this.codigoPatrimonial = codigoPatrimonial;
        this.nombre = nombre;
        this.tipo = tipo;
        this.estado = estado;
    }

    public String getCodigoPatrimonial() {
        return codigoPatrimonial;
    }

    public void setCodigoPatrimonial(String codigoPatrimonial) {
        this.codigoPatrimonial = codigoPatrimonial;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }
}
