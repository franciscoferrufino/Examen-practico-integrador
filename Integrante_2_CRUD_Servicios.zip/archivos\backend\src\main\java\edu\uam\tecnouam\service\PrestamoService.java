package edu.uam.tecnouam.service;

import edu.uam.tecnouam.dto.PrestamoRequestDTO;
import edu.uam.tecnouam.dto.PrestamoResponseDTO;
import edu.uam.tecnouam.exception.BadRequestException;
import edu.uam.tecnouam.exception.BusinessConflictException;
import edu.uam.tecnouam.exception.ResourceNotFoundException;
import edu.uam.tecnouam.model.Equipo;
import edu.uam.tecnouam.model.EstadoEquipo;
import edu.uam.tecnouam.model.EstadoPrestamo;
import edu.uam.tecnouam.model.Prestamo;
import edu.uam.tecnouam.repository.EquipoRepository;
import edu.uam.tecnouam.repository.PrestamoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

/**
 * Capa de servicio para la gestión transaccional de préstamos y devoluciones de equipos.
 * Responsabilidad técnica: Integrante 2 (CRUD, controladores y servicios).
 */
@Service
public class PrestamoService {

    private final PrestamoRepository prestamoRepository;
    private final EquipoRepository equipoRepository;

    public PrestamoService(PrestamoRepository prestamoRepository, EquipoRepository equipoRepository) {
        this.prestamoRepository = prestamoRepository;
        this.equipoRepository = equipoRepository;
    }

    @Transactional(readOnly = true)
    public List<PrestamoResponseDTO> listarPrestamos() {
        return prestamoRepository.findAllByOrderByIdDesc()
                .stream()
                .map(PrestamoResponseDTO::fromEntity)
                .toList();
    }

    /**
     * Registra un préstamo nuevo y cambia el estado del equipo a PRESTADO dentro de una misma transacción.
     * Utiliza bloqueo pesimista (PESSIMISTIC_WRITE) sobre la fila del equipo para evitar que dos
     * solicitudes simultáneas generen dos préstamos activos del mismo equipo.
     */
    @Transactional
    public PrestamoResponseDTO registrarPrestamo(PrestamoRequestDTO request) {
        Long equipoId = request.resolveEquipoId();
        if (equipoId == null) {
            throw new BadRequestException("El identificador del equipo (equipoId) es obligatorio.");
        }

        if (request.getNombreSolicitante() == null || request.getNombreSolicitante().trim().isEmpty()) {
            throw new BadRequestException("El nombre del solicitante es obligatorio.");
        }

        LocalDate fechaPrestamo = request.getFechaPrestamo();
        LocalDate fechaDevolucionPrevista = request.getFechaDevolucionPrevista();
        if (fechaPrestamo == null || fechaDevolucionPrevista == null) {
            throw new BadRequestException("La fecha de préstamo y la fecha prevista de devolución son obligatorias.");
        }

        if (fechaDevolucionPrevista.isBefore(fechaPrestamo)) {
            throw new BadRequestException(
                    "La fecha prevista de devolución (" + fechaDevolucionPrevista
                            + ") no puede ser anterior a la fecha de préstamo (" + fechaPrestamo + ")."
            );
        }

        // Bloqueo pesimista sobre el equipo para garantizar exclusión mutua ante concurrencia
        Equipo equipo = equipoRepository.findByIdWithLock(equipoId)
                .orElseThrow(() -> new ResourceNotFoundException("No existe un equipo con el identificador " + equipoId + "."));

        boolean yaTienePrestamoActivo = prestamoRepository.existsByEquipoIdAndEstado(equipoId, EstadoPrestamo.ACTIVO);
        if (equipo.getEstado() == EstadoEquipo.PRESTADO || yaTienePrestamoActivo) {
            throw new BusinessConflictException(
                    "No se puede prestar el equipo '" + equipo.getCodigoPatrimonial()
                            + "' (" + equipo.getNombre() + ") porque ya se encuentra PRESTADO."
            );
        }

        equipo.setEstado(EstadoEquipo.PRESTADO);
        equipoRepository.save(equipo);

        Prestamo prestamo = new Prestamo(
                equipo,
                request.getNombreSolicitante().trim(),
                fechaPrestamo,
                fechaDevolucionPrevista,
                EstadoPrestamo.ACTIVO
        );

        Prestamo guardado = prestamoRepository.save(prestamo);
        return PrestamoResponseDTO.fromEntity(guardado);
    }

    /**
     * Registra la devolución de un préstamo activo y restablece el equipo a DISPONIBLE
     * dentro de una misma transacción atómica.
     */
    @Transactional
    public PrestamoResponseDTO registrarDevolucion(Long prestamoId) {
        Prestamo prestamo = prestamoRepository.findById(prestamoId)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró el préstamo con identificador " + prestamoId + "."));

        if (prestamo.getEstado() == EstadoPrestamo.DEVUELTO) {
            throw new BusinessConflictException("El préstamo con identificador " + prestamoId + " ya fue devuelto previamente.");
        }

        Equipo equipo = equipoRepository.findByIdWithLock(prestamo.getEquipo().getId())
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró el equipo asociado al préstamo."));

        prestamo.setEstado(EstadoPrestamo.DEVUELTO);
        prestamo.setFechaDevolucionReal(LocalDate.now());
        equipo.setEstado(EstadoEquipo.DISPONIBLE);

        equipoRepository.save(equipo);
        Prestamo actualizado = prestamoRepository.save(prestamo);

        return PrestamoResponseDTO.fromEntity(actualizado);
    }
}
