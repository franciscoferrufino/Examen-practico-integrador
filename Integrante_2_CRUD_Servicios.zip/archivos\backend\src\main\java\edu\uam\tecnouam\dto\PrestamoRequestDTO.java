package edu.uam.tecnouam.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;

import java.time.LocalDate;
import java.util.Map;

/**
 * DTO de entrada para registrar un nuevo préstamo.
 * Soporta recibir el identificador del equipo como "equipoId": 1
 * o como objeto anidado "equipo": { "id": 1 } para máxima compatibilidad en Postman.
 */
public class PrestamoRequestDTO {

    private Long equipoId;

    private Map<String, Object> equipo;

    @NotBlank(message = "El nombre del solicitante es obligatorio.")
    @Size(max = 150, message = "El nombre del solicitante no puede exceder 150 caracteres.")
    private String nombreSolicitante;

    @NotNull(message = "La fecha de préstamo es obligatoria (formato YYYY-MM-DD).")
    private LocalDate fechaPrestamo;

    @NotNull(message = "La fecha prevista de devolución es obligatoria (formato YYYY-MM-DD).")
    private LocalDate fechaDevolucionPrevista;

    public PrestamoRequestDTO() {
    }

    public PrestamoRequestDTO(Long equipoId, String nombreSolicitante, LocalDate fechaPrestamo, LocalDate fechaDevolucionPrevista) {
        this.equipoId = equipoId;
        this.nombreSolicitante = nombreSolicitante;
        this.fechaPrestamo = fechaPrestamo;
        this.fechaDevolucionPrevista = fechaDevolucionPrevista;
    }

    /**
     * Resuelve el identificador del equipo tanto si se envió directo en "equipoId"
     * como si se envió anidado dentro de "equipo": { "id": ... }.
     */
    public Long resolveEquipoId() {
        if (equipoId != null) {
            return equipoId;
        }
        if (equipo != null && equipo.get("id") != null) {
            Object rawId = equipo.get("id");
            if (rawId instanceof Number number) {
                return number.longValue();
            }
            try {
                return Long.parseLong(rawId.toString());
            } catch (NumberFormatException ignored) {
                return null;
            }
        }
        return null;
    }

    public Long getEquipoId() {
        return equipoId;
    }

    public void setEquipoId(Long equipoId) {
        this.equipoId = equipoId;
    }

    public Map<String, Object> getEquipo() {
        return equipo;
    }

    public void setEquipo(Map<String, Object> equipo) {
        this.equipo = equipo;
    }

    public String getNombreSolicitante() {
        return nombreSolicitante;
    }

    public void setNombreSolicitante(String nombreSolicitante) {
        this.nombreSolicitante = nombreSolicitante;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(LocalDate fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public LocalDate getFechaDevolucionPrevista() {
        return fechaDevolucionPrevista;
    }

    public void setFechaDevolucionPrevista(LocalDate fechaDevolucionPrevista) {
        this.fechaDevolucionPrevista = fechaDevolucionPrevista;
    }
}
