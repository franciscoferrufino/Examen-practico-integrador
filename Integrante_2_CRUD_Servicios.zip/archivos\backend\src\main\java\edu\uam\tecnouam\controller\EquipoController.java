package edu.uam.tecnouam.controller;

import edu.uam.tecnouam.dto.EquipoRequestDTO;
import edu.uam.tecnouam.dto.EquipoResponseDTO;
import edu.uam.tecnouam.service.EquipoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador REST para la gestión de equipos tecnológicos de TecnoUAM.
 * Rutas implementadas:
 * - GET    /api/equipos      (200 OK)
 * - GET    /api/equipos/{id} (200 OK / 404 Not Found)
 * - POST   /api/equipos      (201 Created / 400 Bad Request / 409 Conflict)
 * - PUT    /api/equipos/{id} (200 OK / 400 Bad Request / 404 Not Found / 409 Conflict)
 * - DELETE /api/equipos/{id} (204 No Content / 404 Not Found / 409 Conflict)
 */
@RestController
@RequestMapping("/api/equipos")
public class EquipoController {

    private final EquipoService equipoService;

    public EquipoController(EquipoService equipoService) {
        this.equipoService = equipoService;
    }

    @GetMapping
    public ResponseEntity<List<EquipoResponseDTO>> listarEquipos() {
        return ResponseEntity.ok(equipoService.listarEquipos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<EquipoResponseDTO> obtenerEquipoPorId(@PathVariable Long id) {
        return ResponseEntity.ok(equipoService.obtenerEquipoPorId(id));
    }

    @PostMapping
    public ResponseEntity<EquipoResponseDTO> crearEquipo(@Valid @RequestBody EquipoRequestDTO request) {
        EquipoResponseDTO creado = equipoService.crearEquipo(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @PutMapping("/{id}")
    public ResponseEntity<EquipoResponseDTO> actualizarEquipo(
            @PathVariable Long id,
            @Valid @RequestBody EquipoRequestDTO request
    ) {
        return ResponseEntity.ok(equipoService.actualizarEquipo(id, request));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarEquipo(@PathVariable Long id) {
        equipoService.eliminarEquipo(id);
        return ResponseEntity.noContent().build();
    }
}
