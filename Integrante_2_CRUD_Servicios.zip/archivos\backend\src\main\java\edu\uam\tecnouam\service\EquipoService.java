package edu.uam.tecnouam.service;

import edu.uam.tecnouam.dto.EquipoRequestDTO;
import edu.uam.tecnouam.dto.EquipoResponseDTO;
import edu.uam.tecnouam.exception.BadRequestException;
import edu.uam.tecnouam.exception.BusinessConflictException;
import edu.uam.tecnouam.exception.ResourceNotFoundException;
import edu.uam.tecnouam.model.Equipo;
import edu.uam.tecnouam.model.EstadoEquipo;
import edu.uam.tecnouam.model.EstadoPrestamo;
import edu.uam.tecnouam.model.TipoEquipo;
import edu.uam.tecnouam.repository.EquipoRepository;
import edu.uam.tecnouam.repository.PrestamoRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Locale;

/**
 * Capa de servicio para la gestión de equipos tecnológicos y sus reglas de negocio.
 * Responsabilidad técnica: Integrante 2 (CRUD, controladores y servicios).
 */
@Service
public class EquipoService {

    private final EquipoRepository equipoRepository;
    private final PrestamoRepository prestamoRepository;

    public EquipoService(EquipoRepository equipoRepository, PrestamoRepository prestamoRepository) {
        this.equipoRepository = equipoRepository;
        this.prestamoRepository = prestamoRepository;
    }

    @Transactional(readOnly = true)
    public List<EquipoResponseDTO> listarEquipos() {
        return equipoRepository.findAllByOrderByIdAsc()
                .stream()
                .map(EquipoResponseDTO::fromEntity)
                .toList();
    }

    @Transactional(readOnly = true)
    public EquipoResponseDTO obtenerEquipoPorId(Long id) {
        Equipo equipo = equipoRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró el equipo con identificador " + id + "."));
        return EquipoResponseDTO.fromEntity(equipo);
    }

    @Transactional
    public EquipoResponseDTO crearEquipo(EquipoRequestDTO request) {
        String codigo = validarTextoObligatorio(request.getCodigoPatrimonial(), "El código patrimonial es obligatorio.");
        String nombre = validarTextoObligatorio(request.getNombre(), "El nombre del equipo es obligatorio.");
        String tipoNormalizado = TipoEquipo.normalizarYValidar(request.getTipo());

        if (equipoRepository.existsByCodigoPatrimonialIgnoreCase(codigo)) {
            throw new BusinessConflictException("Ya existe un equipo registrado con el código patrimonial '" + codigo + "'.");
        }

        EstadoEquipo estadoInicial = EstadoEquipo.DISPONIBLE;
        if (request.getEstado() != null && !request.getEstado().trim().isEmpty()) {
            EstadoEquipo estadoSolicitado = parsearEstadoEquipo(request.getEstado());
            if (estadoSolicitado == EstadoEquipo.PRESTADO) {
                throw new BusinessConflictException(
                        "No se puede crear un equipo directamente en estado PRESTADO sin un préstamo activo. Regístrelo como DISPONIBLE."
                );
            }
            estadoInicial = estadoSolicitado;
        }

        Equipo nuevoEquipo = new Equipo(codigo, nombre, tipoNormalizado, estadoInicial);
        Equipo guardado = equipoRepository.save(nuevoEquipo);
        return EquipoResponseDTO.fromEntity(guardado);
    }

    @Transactional
    public EquipoResponseDTO actualizarEquipo(Long id, EquipoRequestDTO request) {
        Equipo equipo = equipoRepository.findByIdWithLock(id)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró el equipo con identificador " + id + "."));

        String codigo = validarTextoObligatorio(request.getCodigoPatrimonial(), "El código patrimonial es obligatorio.");
        String nombre = validarTextoObligatorio(request.getNombre(), "El nombre del equipo es obligatorio.");
        String tipoNormalizado = TipoEquipo.normalizarYValidar(request.getTipo());

        if (equipoRepository.existsByCodigoPatrimonialIgnoreCaseAndIdNot(codigo, id)) {
            throw new BusinessConflictException("Ya existe otro equipo registrado con el código patrimonial '" + codigo + "'.");
        }

        boolean tienePrestamoActivo = prestamoRepository.existsByEquipoIdAndEstado(id, EstadoPrestamo.ACTIVO);

        if (request.getEstado() != null && !request.getEstado().trim().isEmpty()) {
            EstadoEquipo nuevoEstado = parsearEstadoEquipo(request.getEstado());

            if (tienePrestamoActivo && nuevoEstado == EstadoEquipo.DISPONIBLE) {
                throw new BusinessConflictException(
                        "No se puede cambiar manualmente el estado del equipo a DISPONIBLE porque posee un préstamo ACTIVO. Debe registrar la devolución del préstamo."
                );
            }
            if (!tienePrestamoActivo && nuevoEstado == EstadoEquipo.PRESTADO) {
                throw new BusinessConflictException(
                        "No se puede cambiar manualmente el estado del equipo a PRESTADO porque no posee ningún préstamo ACTIVO."
                );
            }
            equipo.setEstado(nuevoEstado);
        }

        equipo.setCodigoPatrimonial(codigo);
        equipo.setNombre(nombre);
        equipo.setTipo(tipoNormalizado);

        Equipo actualizado = equipoRepository.save(equipo);
        return EquipoResponseDTO.fromEntity(actualizado);
    }

    /**
     * Elimina un equipo tecnológico únicamente si no tiene préstamos activos.
     * Estrategia para equipos con préstamos ya DEVUELTOS:
     * Si el equipo no tiene préstamos ACTIVOS, dentro de la misma transacción se depuran
     * primero sus registros históricos en estado DEVUELTO en la tabla 'prestamos' y luego
     * se elimina el registro en 'equipos', evitando errores de restricción de clave foránea (FK).
     */
    @Transactional
    public void eliminarEquipo(Long id) {
        Equipo equipo = equipoRepository.findByIdWithLock(id)
                .orElseThrow(() -> new ResourceNotFoundException("No se encontró el equipo con identificador " + id + "."));

        boolean tienePrestamoActivo = prestamoRepository.existsByEquipoIdAndEstado(id, EstadoPrestamo.ACTIVO);
        if (tienePrestamoActivo || equipo.getEstado() == EstadoEquipo.PRESTADO) {
            throw new BusinessConflictException(
                    "No se permite eliminar el equipo '" + equipo.getCodigoPatrimonial() + "' porque tiene un préstamo ACTIVO."
            );
        }

        // Eliminar préstamos históricos ya devueltos antes de eliminar el equipo para respetar la clave foránea
        prestamoRepository.deleteByEquipoIdAndEstado(id, EstadoPrestamo.DEVUELTO);
        equipoRepository.delete(equipo);
    }

    private String validarTextoObligatorio(String valor, String mensajeError) {
        if (valor == null || valor.trim().isEmpty()) {
            throw new BadRequestException(mensajeError);
        }
        return valor.trim();
    }

    private EstadoEquipo parsearEstadoEquipo(String estadoTexto) {
        try {
            return EstadoEquipo.valueOf(estadoTexto.trim().toUpperCase(Locale.ROOT));
        } catch (IllegalArgumentException ex) {
            throw new BadRequestException(
                    "Estado de equipo inválido: '" + estadoTexto + "'. Valores permitidos: DISPONIBLE o PRESTADO."
            );
        }
    }
}
