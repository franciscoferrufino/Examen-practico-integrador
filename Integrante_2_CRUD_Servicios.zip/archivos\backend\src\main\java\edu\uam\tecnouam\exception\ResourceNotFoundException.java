package edu.uam.tecnouam.exception;

/**
 * Excepción para recursos inexistentes en la base de datos (HTTP 404 Not Found).
 */
public class ResourceNotFoundException extends RuntimeException {
    public ResourceNotFoundException(String message) {
        super(message);
    }
}
