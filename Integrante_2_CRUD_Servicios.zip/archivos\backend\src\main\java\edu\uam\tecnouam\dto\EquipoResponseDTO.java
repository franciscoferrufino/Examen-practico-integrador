package edu.uam.tecnouam.dto;

import edu.uam.tecnouam.model.Equipo;
import edu.uam.tecnouam.model.EstadoEquipo;

/**
 * DTO de salida para representar un equipo tecnológico.
 */
public class EquipoResponseDTO {

    private Long id;
    private String codigoPatrimonial;
    private String nombre;
    private String tipo;
    private EstadoEquipo estado;

    public EquipoResponseDTO() {
    }

    public EquipoResponseDTO(Long id, String codigoPatrimonial, String nombre, String tipo, EstadoEquipo estado) {
        this.id = id;
        this.codigoPatrimonial = codigoPatrimonial;
        this.nombre = nombre;
        this.tipo = tipo;
        this.estado = estado;
    }

    public static EquipoResponseDTO fromEntity(Equipo equipo) {
        return new EquipoResponseDTO(
                equipo.getId(),
                equipo.getCodigoPatrimonial(),
                equipo.getNombre(),
                equipo.getTipo(),
                equipo.getEstado()
        );
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getCodigoPatrimonial() {
        return codigoPatrimonial;
    }

    public void setCodigoPatrimonial(String codigoPatrimonial) {
        this.codigoPatrimonial = codigoPatrimonial;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public String getTipo() {
        return tipo;
    }

    public void setTipo(String tipo) {
        this.tipo = tipo;
    }

    public EstadoEquipo getEstado() {
        return estado;
    }

    public void setEstado(EstadoEquipo estado) {
        this.estado = estado;
    }
}
