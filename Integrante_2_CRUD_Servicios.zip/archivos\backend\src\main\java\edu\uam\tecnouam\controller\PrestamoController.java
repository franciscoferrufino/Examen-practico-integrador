package edu.uam.tecnouam.controller;

import edu.uam.tecnouam.dto.PrestamoRequestDTO;
import edu.uam.tecnouam.dto.PrestamoResponseDTO;
import edu.uam.tecnouam.service.PrestamoService;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/**
 * Controlador REST para la gestión de préstamos y devoluciones de TecnoUAM.
 * Rutas implementadas:
 * - GET  /api/prestamos               (200 OK)
 * - POST /api/prestamos               (201 Created / 400 Bad Request / 404 Not Found / 409 Conflict)
 * - PUT  /api/prestamos/{id}/devolver (200 OK / 404 Not Found / 409 Conflict)
 */
@RestController
@RequestMapping("/api/prestamos")
public class PrestamoController {

    private final PrestamoService prestamoService;

    public PrestamoController(PrestamoService prestamoService) {
        this.prestamoService = prestamoService;
    }

    @GetMapping
    public ResponseEntity<List<PrestamoResponseDTO>> listarPrestamos() {
        return ResponseEntity.ok(prestamoService.listarPrestamos());
    }

    @PostMapping
    public ResponseEntity<PrestamoResponseDTO> registrarPrestamo(@Valid @RequestBody PrestamoRequestDTO request) {
        PrestamoResponseDTO creado = prestamoService.registrarPrestamo(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(creado);
    }

    @PutMapping("/{id}/devolver")
    public ResponseEntity<PrestamoResponseDTO> registrarDevolucion(@PathVariable Long id) {
        return ResponseEntity.ok(prestamoService.registrarDevolucion(id));
    }
}
