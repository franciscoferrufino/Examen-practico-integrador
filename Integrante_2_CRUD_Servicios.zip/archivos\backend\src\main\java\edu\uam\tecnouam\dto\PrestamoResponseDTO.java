package edu.uam.tecnouam.dto;

import edu.uam.tecnouam.model.EstadoPrestamo;
import edu.uam.tecnouam.model.Prestamo;

import java.time.LocalDate;

/**
 * DTO de salida para representar un préstamo y la información de su equipo tecnológico asociado.
 */
public class PrestamoResponseDTO {

    private Long id;
    private Long equipoId;
    private EquipoResponseDTO equipo;
    private String nombreSolicitante;
    private LocalDate fechaPrestamo;
    private LocalDate fechaDevolucionPrevista;
    private LocalDate fechaDevolucionReal;
    private EstadoPrestamo estado;

    public PrestamoResponseDTO() {
    }

    public static PrestamoResponseDTO fromEntity(Prestamo prestamo) {
        PrestamoResponseDTO dto = new PrestamoResponseDTO();
        dto.setId(prestamo.getId());
        if (prestamo.getEquipo() != null) {
            dto.setEquipoId(prestamo.getEquipo().getId());
            dto.setEquipo(EquipoResponseDTO.fromEntity(prestamo.getEquipo()));
        }
        dto.setNombreSolicitante(prestamo.getNombreSolicitante());
        dto.setFechaPrestamo(prestamo.getFechaPrestamo());
        dto.setFechaDevolucionPrevista(prestamo.getFechaDevolucionPrevista());
        dto.setFechaDevolucionReal(prestamo.getFechaDevolucionReal());
        dto.setEstado(prestamo.getEstado());
        return dto;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public Long getEquipoId() {
        return equipoId;
    }

    public void setEquipoId(Long equipoId) {
        this.equipoId = equipoId;
    }

    public EquipoResponseDTO getEquipo() {
        return equipo;
    }

    public void setEquipo(EquipoResponseDTO equipo) {
        this.equipo = equipo;
    }

    public String getNombreSolicitante() {
        return nombreSolicitante;
    }

    public void setNombreSolicitante(String nombreSolicitante) {
        this.nombreSolicitante = nombreSolicitante;
    }

    public LocalDate getFechaPrestamo() {
        return fechaPrestamo;
    }

    public void setFechaPrestamo(LocalDate fechaPrestamo) {
        this.fechaPrestamo = fechaPrestamo;
    }

    public LocalDate getFechaDevolucionPrevista() {
        return fechaDevolucionPrevista;
    }

    public void setFechaDevolucionPrevista(LocalDate fechaDevolucionPrevista) {
        this.fechaDevolucionPrevista = fechaDevolucionPrevista;
    }

    public LocalDate getFechaDevolucionReal() {
        return fechaDevolucionReal;
    }

    public void setFechaDevolucionReal(LocalDate fechaDevolucionReal) {
        this.fechaDevolucionReal = fechaDevolucionReal;
    }

    public EstadoPrestamo getEstado() {
        return estado;
    }

    public void setEstado(EstadoPrestamo estado) {
        this.estado = estado;
    }
}
