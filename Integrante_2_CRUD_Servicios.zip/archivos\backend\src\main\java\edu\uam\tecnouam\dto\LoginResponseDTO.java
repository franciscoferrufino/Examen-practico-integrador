package edu.uam.tecnouam.dto;

/**
 * DTO de salida al iniciar sesión exitosamente en POST /api/auth/login.
 */
public class LoginResponseDTO {

    private String token;
    private String tokenType = "Bearer";
    private String username;
    private String nombreCompleto;
    private String rol;
    private long expiresInMs;

    public LoginResponseDTO() {
    }

    public LoginResponseDTO(String token, String username, String nombreCompleto, String rol, long expiresInMs) {
        this.token = token;
        this.tokenType = "Bearer";
        this.username = username;
        this.nombreCompleto = nombreCompleto;
        this.rol = rol;
        this.expiresInMs = expiresInMs;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    public String getTokenType() {
        return tokenType;
    }

    public void setTokenType(String tokenType) {
        this.tokenType = tokenType;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNombreCompleto() {
        return nombreCompleto;
    }

    public void setNombreCompleto(String nombreCompleto) {
        this.nombreCompleto = nombreCompleto;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) {
        this.rol = rol;
    }

    public long getExpiresInMs() {
        return expiresInMs;
    }

    public void setExpiresInMs(long expiresInMs) {
        this.expiresInMs = expiresInMs;
    }
}
