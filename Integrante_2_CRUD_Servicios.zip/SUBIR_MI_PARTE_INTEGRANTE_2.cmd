@echo off
cd /d "%~dp0"
echo Clonando repositorio de TecnoUAM...
if exist repo_uam rmdir /s /q repo_uam
git clone https://github.com/franciscoferrufino/Examen-practico-integrador.git repo_uam
xcopy /E /I /Y "archivos\*" "repo_uam\"
cd repo_uam
git add .
git commit -m "feat(api-crud): servicios transaccionales, reglas de negocio, DTOs, controladores y manejo de errores 400/404/409"
git push origin main
echo.
echo ==========================================================
echo   LISTO! TU COMMIT DE INTEGRANTE 2 SE SUBIO A GITHUB
echo ==========================================================
pause
