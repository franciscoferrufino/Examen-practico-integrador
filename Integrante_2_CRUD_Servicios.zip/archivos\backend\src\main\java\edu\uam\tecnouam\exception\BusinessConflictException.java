package edu.uam.tecnouam.exception;

/**
 * Excepción para conflictos con reglas de negocio o integridad (HTTP 409 Conflict).
 */
public class BusinessConflictException extends RuntimeException {
    public BusinessConflictException(String message) {
        super(message);
    }
}
